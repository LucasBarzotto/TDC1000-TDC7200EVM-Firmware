/* --COPYRIGHT--,BSD
* Copyright (c) 2014, Texas Instruments Incorporated
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
*
* * Redistributions of source code must retain the above copyright
* notice, this list of conditions and the following disclaimer.
*
* * Redistributions in binary form must reproduce the above copyright
* notice, this list of conditions and the following disclaimer in the
* documentation and/or other materials provided with the distribution.
*
* * Neither the name of Texas Instruments Incorporated nor the names of
* its contributors may be used to endorse or promote products derived
* from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
* THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
* PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
* EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
* OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
* WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
* --/COPYRIGHT--*/

#include <stdint.h>
#include "TI_TDC1000.h"
#include "TI_TDC7200.h"
#include "TI_MSP430.h"
#include "TI_MSP430_hardware_board.h"
#include "TI_MSP430_spi.h"

//******************************************************************************
// Support for 552x USCI_B0
//******************************************************************************
#if TI_TDC1000_SER_INTF == TI_TDC1000_SER_INTF_USCIB0_5xx

//------------------------------------------------------------------------------
//  void TI_TDC1000_SPISetup(void)
//
//  DESCRIPTION:
//  Configures the assigned interface to function as a SPI port and
//  initializes it.
//------------------------------------------------------------------------------
void TI_TDC1000_SPISetup(void)
{
  TI_TDC1000_CSn_PxOUT |= TI_TDC1000_CSn_PIN;
  TI_TDC1000_CSn_PxDIR |= TI_TDC1000_CSn_PIN;                                // /CS disable

  UCB0CTL1 |= UCSWRST;                                                         // **Disable USCI state machine**
  UCB0CTL0 |= UCMST+UCMSB+UCCKPH+UCSYNC;                                              // 3-pin, 8-bit SPI master 
  UCB0CTL1 |= UCSSEL__SMCLK;                                                    // choose SMCLK

  UCB0BR0 = 0x02;                                                              // UCLK/2 (should be 12MHz for 24MHz SMCLK)
  UCB0BR1 = 0;
  TI_TDC1000_SPI_USCIB0_PxSEL1 |= TI_TDC1000_SPI_USCIB0_SIMO
                                   | TI_TDC1000_SPI_USCIB0_SOMI;              
  TI_TDC1000_SPI_USCIB0_PxSEL2 |= TI_TDC1000_SPI_USCIB0_UCLK;
                                                                               // SPI option select
  TI_TDC1000_SPI_USCIB0_PxDIR1 |= TI_TDC1000_SPI_USCIB0_SIMO;
  TI_TDC1000_SPI_USCIB0_PxDIR2 |= TI_TDC1000_SPI_USCIB0_UCLK;
                                                                               // SPI TXD out direction
  
  UCB0CTL1 &= ~UCSWRST;                                                        // **Initialize USCI state machine**
}

//------------------------------------------------------------------------------
//  void TI_TDC1000_SPIByteWriteReg(uint8_t addr, uint8_t value)
//
//  DESCRIPTION:
//  Writes "value" to a single configuration register at address "addr". Note addr is
//  is 8-bit, data written is 8-bit 
//------------------------------------------------------------------------------
void TI_TDC1000_SPIByteWriteReg(uint8_t addr, uint8_t value)
{
  uint8_t inst;
 

  TI_TDC1000_CSn_PxOUT &= ~TI_TDC1000_CSn_PIN;                               // /CS enable 
  
  inst = TDC1000_WRITE_BIT | addr;                                            // for write make sure bit6 is 1 
  
  while (!(UCB0IFG&UCTXIFG));                                                  // Wait for TXBUF ready
  UCB0TXBUF = inst;                                                            // Send MSB of address
   
  while (!(UCB0IFG&UCTXIFG));                                                  // Wait for TXBUF ready
  UCB0TXBUF = value;                                                           // Send data value  
  
  while (UCB0STAT & UCBUSY);                                                   // Wait for TX complete
  TI_TDC1000_CSn_PxOUT |= TI_TDC1000_CSn_PIN;                                // /CS disable

}

//------------------------------------------------------------------------------
//  uint8_t TI_TDC1000_SPIByteReadReg(uint8_t addr)
//
//  DESCRIPTION:
//  Reads a single configuration register byte at address "addr" and returns the
//  value read. Note addr is 8-bit, return data is 8-bit  
//------------------------------------------------------------------------------
uint8_t TI_TDC1000_SPIByteReadReg(uint8_t addr)
{
  uint8_t x, inst;
  
  TI_TDC1000_CSn_PxOUT &= ~TI_TDC1000_CSn_PIN;                               // /CS enable
  
  inst = TDC1000_READ_BIT & addr;                                            // for read make sure bit6 is 0 
  
  while (!(UCB0IFG&UCTXIFG));                                                  // Wait for TXBUF ready
  UCB0TXBUF = inst;                                                            // Send LSB of address
  
  while (!(UCB0IFG&UCTXIFG));                                                  // Wait for TXBUF ready
  UCB0TXBUF = 0;                                                               // Dummy write so we can read data
  
  while (UCB0STAT & UCBUSY);                                                   // Wait for TX complete  
  x = UCB0RXBUF;                                                               // Read data
  
  TI_TDC1000_CSn_PxOUT |= TI_TDC1000_CSn_PIN;                                // /CS disable
     
  return x;
}
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
//  void TI_TDC7200_SPISetup(void)
//
//  DESCRIPTION:
//  Configures the assigned interface to function as a SPI port and
//  initializes it.
//------------------------------------------------------------------------------
void TI_TDC7200_SPISetup(void)
{
  TI_TDC7200_CSn_PxOUT |= TI_TDC7200_CSn_PIN;
  TI_TDC7200_CSn_PxDIR |= TI_TDC7200_CSn_PIN;                                  // /CS disable

  UCB0CTL1 |= UCSWRST;                                                         // **Disable USCI state machine**
  UCB0CTL0 |= UCMST+UCMSB+UCCKPH+UCSYNC;                                       // 3-pin, 8-bit SPI master 
  UCB0CTL1 |= UCSSEL__SMCLK;                                                    // choose SMCLK
  // vishy
  UCB0BR0 = 0x02;                                                              // UCLK/2 (should be 12MHz for 24MHz SMCLK)
  UCB0BR1 = 0;

  TI_TDC1000_SPI_USCIB0_PxSEL1 |= TI_TDC1000_SPI_USCIB0_SIMO
                                   | TI_TDC1000_SPI_USCIB0_SOMI;              
  TI_TDC1000_SPI_USCIB0_PxSEL2 |= TI_TDC1000_SPI_USCIB0_UCLK;
                                                                               // SPI option select
  TI_TDC1000_SPI_USCIB0_PxDIR1 |= TI_TDC1000_SPI_USCIB0_SIMO;
  TI_TDC1000_SPI_USCIB0_PxDIR2 |= TI_TDC1000_SPI_USCIB0_UCLK;
                                                                               // SPI TXD out direction
  
  UCB0CTL1 &= ~UCSWRST;                                                        // **Initialize USCI state machine**
}

//------------------------------------------------------------------------------
//  void TI_TDC7200_SPIByteWriteReg(uint8_t addr, uint8_t value)
//
//  DESCRIPTION:
//  Writes "value" to a single configuration register at address "addr". Note addr is
//  is 8-bit, data written is 8-bit 
//------------------------------------------------------------------------------
void TI_TDC7200_SPIByteWriteReg(uint8_t addr, uint8_t value)
{
  uint8_t inst;
 

  TI_TDC7200_CSn_PxOUT &= ~TI_TDC7200_CSn_PIN;                                 // /CS enable 
  
  // write mode and auto inc off
  inst = TDC7200_WRITE_BIT | addr;                                             
  inst = TDC7200_AUTOINC_OFF_BIT & inst;
   
  while (!(UCB0IFG&UCTXIFG));                                                  // Wait for TXBUF ready
  UCB0TXBUF = inst;                                                            // Send MSB of address

   
  while (!(UCB0IFG&UCTXIFG));                                                  // Wait for TXBUF ready
  UCB0TXBUF = value;                                                           // Send data value  
  
   
  while (UCB0STAT & UCBUSY);                                                   // Wait for TX complete
  TI_TDC7200_CSn_PxOUT |= TI_TDC7200_CSn_PIN;                                  // /CS disable

}

//------------------------------------------------------------------------------
//  uint8_t TI_TDC7200_SPIByteReadReg(uint8_t addr)
//
//  DESCRIPTION:
//  Reads a single configuration register byte at address "addr" and returns the
//  value read. Note addr is 8-bit, return data is 8-bit  
//------------------------------------------------------------------------------
uint8_t TI_TDC7200_SPIByteReadReg(uint8_t addr)
{
  uint8_t x, inst;
  
  TI_TDC7200_CSn_PxOUT &= ~TI_TDC7200_CSn_PIN;                                 // /CS enable
  
  // read mode and auto_inc off
  inst = TDC7200_READ_BIT & addr;                                               
  inst = TDC7200_AUTOINC_OFF_BIT & inst;
  
  while (!(UCB0IFG&UCTXIFG));                                                  // Wait for TXBUF ready
  UCB0TXBUF = inst;                                                            // Send LSB of address
    
  while (!(UCB0IFG&UCTXIFG));                                                  // Wait for TXBUF ready
  UCB0TXBUF = 0;                                                               // Dummy write so we can read data
    
  while (UCB0STAT & UCBUSY);                                                   // Wait for TX complete  
  x = UCB0RXBUF;                                                               // Read data
  
  TI_TDC7200_CSn_PxOUT |= TI_TDC7200_CSn_PIN;                                  // /CS disable
     
  return x;
}
//------------------------------------------------------------------------------
//  void TI_TDC7200_SPIAutoIncWriteReg(uint8_t addr, uint8_t *buffer, uint8_t size)
//
//  DESCRIPTION:
//  Writes "value" to a single configuration register at address "addr". Note addr is
//  is 8-bit, data written is 8-bit 
//------------------------------------------------------------------------------
void TI_TDC7200_SPIAutoIncWriteReg(uint8_t addr, uint8_t *buffer, uint8_t size)
{
  uint8_t i, inst;
 

  TI_TDC7200_CSn_PxOUT &= ~TI_TDC7200_CSn_PIN;                                 // /CS enable 
  
  // write mode and auto inc on
  inst = TDC7200_WRITE_BIT | addr;                                             
  inst = TDC7200_AUTOINC_ON_BIT | inst;
   
  while (!(UCB0IFG&UCTXIFG));                                                  // Wait for TXBUF ready
  UCB0TXBUF = inst;                                                            // Send MSB of address

   
  for(i=0; i<size; i++)
  {
    while (!(UCB0IFG&UCTXIFG));                                                // Wait for TXBUF ready
    UCB0TXBUF = *(buffer+i);                                                   // Dummy write so we can read data
  }  
   
  while (UCB0STAT & UCBUSY);                                                   // Wait for TX complete
  TI_TDC7200_CSn_PxOUT |= TI_TDC7200_CSn_PIN;                                  // /CS disable

}
//------------------------------------------------------------------------------
//  void TI_TDC7200_SPIAutoIncReadReg(uint8_t addr, uint8_t *buffer, uint8_t size)
//
//  DESCRIPTION:
//  
//  
//------------------------------------------------------------------------------
void TI_TDC7200_SPIAutoIncReadReg(uint8_t addr, uint8_t *buffer, uint8_t size)
{
  uint8_t i, inst;
 

  TI_TDC7200_CSn_PxOUT &= ~TI_TDC7200_CSn_PIN;                                 // /CS enable 
  
  // read mode and auto inc on
  inst = TDC7200_READ_BIT & addr;                                             
  inst = TDC7200_AUTOINC_ON_BIT | inst;
   
  while (!(UCB0IFG&UCTXIFG));                                                  // Wait for TXBUF ready
  UCB0TXBUF = inst;                                                            // Send address

   
  for(i=0; i<size; i++)
  {
    while (!(UCB0IFG&UCTXIFG));                                                // Wait for TXBUF ready
    UCB0TXBUF = 0;                                                             // Dummy write so we can read data
       
    while (UCB0STAT & UCBUSY);                                                 // Wait for TX complete  
    *(buffer+i) = UCB0RXBUF;                                                   // Read register data        
  }  
   
  TI_TDC7200_CSn_PxOUT |= TI_TDC7200_CSn_PIN;                                  // /CS disable

}
//------------------------------------------------------------------------------
//  void TI_TDC7200_SPIAllReadReg(uint8_t *buffer)
//
//  DESCRIPTION:
//  Special read function for reading all measurement result registers.
//  Data read are deposited sequentially starting at address "buffer" 
//------------------------------------------------------------------------------
void TI_TDC7200_SPIAllReadReg(uint8_t *buffer)
{

  uint8_t i, inst;
  
  TI_TDC7200_CSn_PxOUT &= ~TI_TDC7200_CSn_PIN;                                 // /CS enable
 
  // read mode and auto_inc on
  inst = 0x90;
  
  while (!(UCB0IFG&UCTXIFG));                                                  // Wait for TXBUF ready
  UCB0TXBUF = inst;                                                            // Send register address
  
 
  for(i=0; i<TDC7200_ALL_DATA_SIZE; i++)
  {
    while (!(UCB0IFG&UCTXIFG));                                                // Wait for TXBUF ready
    UCB0TXBUF = 0;                                                             // Dummy write so we can read data
    
   
    while (UCB0STAT & UCBUSY);                                                 // Wait for TX complete  
    *(buffer+i) = UCB0RXBUF;                                                   // Read register data    
  }
    
  TI_TDC7200_CSn_PxOUT |= TI_TDC7200_CSn_PIN;                                  // /CS disable
    
}
//------------------------------------------------------------------------------
//  uint32_t TI_TDC7200_SPILongReadReg(uint8_t addr)
//
//  DESCRIPTION:
//  Reads a single measurement result register at address "addr" and returns the
//  value read. Note addr is 8-bit  
//  Return data is 32-bit, MSB is read first, then middle, finally LSB
//------------------------------------------------------------------------------
uint32_t TI_TDC7200_SPILongReadReg(uint8_t addr)
{
  uint8_t inst;
  uint32_t x, y;
  
  x = y = 0;
  TI_TDC7200_CSn_PxOUT &= ~TI_TDC7200_CSn_PIN;                               // /CS enable
  
  // read mode and auto_inc off
  inst = TDC7200_READ_BIT & addr;                                               
  inst = TDC7200_AUTOINC_OFF_BIT & inst;
  
  while (!(UCB0IFG&UCTXIFG));                                                  // Wait for TXBUF ready
  UCB0TXBUF = inst;                                                            // Send address
    
  while (!(UCB0IFG&UCTXIFG));                                                  // Wait for TXBUF ready
  UCB0TXBUF = 0;                                                               // Dummy write so we can read  
    
  while (UCB0STAT & UCBUSY);                                                   // Wait for TX complete  
  y = UCB0RXBUF;                                                               // Read MSB of data
  x |= (y << 16);
  
  while (!(UCB0IFG&UCTXIFG));                                                  // Wait for TXBUF ready
  UCB0TXBUF = 0;                                                               // Dummy write so we can read  
    
  while (UCB0STAT & UCBUSY);                                                   // Wait for TX complete
  y = UCB0RXBUF;  
  x |= (y << 8);                                                               // Read middle byte of data  

  while (!(UCB0IFG&UCTXIFG));                                                  // Wait for TXBUF ready
  UCB0TXBUF = 0;                                                               // Dummy write so we can read  
    
  while (UCB0STAT & UCBUSY);                                                   // Wait for TX complete
  y = UCB0RXBUF;  
  x |= y;                                                                      // Read LSB of data  
  
  TI_TDC7200_CSn_PxOUT |= TI_TDC7200_CSn_PIN;                                  // /CS disable
   
  return x;
}
//------------------------------------------------------------------------------
//  void TI_TDC7200_SPIAllReadRegNoAutoInc(uint8_t *buffer)
//
//  DESCRIPTION:
//  Special read function for reading all measurement result registers.
//  Data read are deposited sequentially starting at address "buffer" 
//------------------------------------------------------------------------------
void TI_TDC7200_SPIAllReadRegNoAutoInc(uint8_t *buffer)
{

  uint8_t i, inst;
  
  
 
  // read mode and auto_inc off
  inst = TDC7200_READ_BIT & 0x10;                                               
  inst = TDC7200_AUTOINC_OFF_BIT & inst;

  for(i=0; i<TDC7200_ALL_DATA_SIZE; i=i+3)
  {
    TI_TDC7200_CSn_PxOUT &= ~TI_TDC7200_CSn_PIN;                                 // /CS enable
    
    while (!(UCB0IFG&UCTXIFG));                                                  // Wait for TXBUF ready
    UCB0TXBUF = inst;                                                            // Send address
    inst++;                                                                      // increment for next read
    
    while (!(UCB0IFG&UCTXIFG));                                                  // Wait for TXBUF ready
    UCB0TXBUF = 0;                                                               // Dummy write so we can read  
    
    while (UCB0STAT & UCBUSY);                                                   // Wait for TX complete  
    *(buffer+i) = UCB0RXBUF;                                                     // Read MSB of data
  
    while (!(UCB0IFG&UCTXIFG));                                                  // Wait for TXBUF ready
    UCB0TXBUF = 0;                                                               // Dummy write so we can read  
    
    while (UCB0STAT & UCBUSY);                                                   // Wait for TX complete
    *(buffer+i+1) = UCB0RXBUF;                                                   // Read middle byte of data  

    while (!(UCB0IFG&UCTXIFG));                                                  // Wait for TXBUF ready
    UCB0TXBUF = 0;                                                               // Dummy write so we can read  
    
    while (UCB0STAT & UCBUSY);                                                   // Wait for TX complete
    *(buffer+i+2) = UCB0RXBUF;                                                   // Read LSB of data
    
    TI_TDC7200_CSn_PxOUT |= TI_TDC7200_CSn_PIN;                                  // /CS disable
  }
}
//------------------------------------------------------------------------------
#endif

