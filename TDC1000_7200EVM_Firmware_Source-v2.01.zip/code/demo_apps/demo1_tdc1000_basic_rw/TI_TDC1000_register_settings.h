//----------------------------------------------------------------------------
//  Description:  This file contains the initialization values for the 
//  TDC1000 registers.
//
//  MSP430/TDC1000 Interface Code Library v1.0
//
//   Vishy Natarajan
//   Texas Instruments Inc.
//   March 2013
//   Built with IAR Embedded Workbench Version:  5.5x
//------------------------------------------------------------------------------
// Change Log:
//------------------------------------------------------------------------------
// Version:  1.00
// Comments: Initial Release Version
//------------------------------------------------------------------------------
#ifndef HEADER_FILE_TI_TDC1000_REGISTER_SETTINGS_H

#define HEADER_FILE_TI_TDC1000_REGISTER_SETTINGS_H

/************************************************************
* TI TDC1000 REGISTER SET INITIALIZATION VALUES
************************************************************/

#define TI_TDC1000_CONFIG0_REG_VALUE                        (0x45)            //  
#define TI_TDC1000_CONFIG1_REG_VALUE                        (0x40)            //  
#define TI_TDC1000_CONFIG2_REG_VALUE                        (0x00)            //  
#define TI_TDC1000_CONFIG3_REG_VALUE                        (0x03)            //  
#define TI_TDC1000_CONFIG4_REG_VALUE                        (0x1F)            //  
#define TI_TDC1000_TOF1_REG_VALUE                           (0x00)            //  
#define TI_TDC1000_TOF0_REG_VALUE                           (0x00)            //  
#define TI_TDC1000_ERROR_FLAGS_REG_VALUE                    (0x00)            // 
#define TI_TDC1000_TIMEOUT_REG_VALUE                        (0x19)            //  
#define TI_TDC1000_CLOCK_RATE_REG_VALUE                     (0x00)            //  
 
#endif                                                        // HEADER_FILE_TI_TDC1000_REGISTER_SETTINGS_H
