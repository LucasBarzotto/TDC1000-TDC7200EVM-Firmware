//----------------------------------------------------------------------------
//  Description:  This file contains the initialization values for the 
//  LMP91400 registers.
//
//  MSP430/LMP91400 Interface Code Library v1.0
//
//   Vishy Natarajan
//   Texas Instruments Inc.
//   March 2013
//   Built with IAR Embedded Workbench Version:  5.5x
//------------------------------------------------------------------------------
// Change Log:
//------------------------------------------------------------------------------
// Version:  1.00
// Comments: Initial Release Version
//------------------------------------------------------------------------------
#ifndef HEADER_FILE_TI_LMP91400_REGISTER_SETTINGS_H

#define HEADER_FILE_TI_LMP91400_REGISTER_SETTINGS_H

/************************************************************
* TI LMP91400 REGISTER SET INITIALIZATION VALUES
************************************************************/

#define TI_LMP91400_CONFIG0_REG_VALUE                        (0x45)            //  
#define TI_LMP91400_CONFIG1_REG_VALUE                        (0x40)            //  
#define TI_LMP91400_CONFIG2_REG_VALUE                        (0x00)            //  
#define TI_LMP91400_CONFIG3_REG_VALUE                        (0x03)            //  
#define TI_LMP91400_CONFIG4_REG_VALUE                        (0x1F)            //  
#define TI_LMP91400_TOF1_REG_VALUE                           (0x00)            //  
#define TI_LMP91400_TOF0_REG_VALUE                           (0x00)            //  
#define TI_LMP91400_ERROR_FLAGS_REG_VALUE                    (0x00)            // 
#define TI_LMP91400_TIMEOUT_REG_VALUE                        (0x19)            //  
#define TI_LMP91400_CLOCK_RATE_REG_VALUE                     (0x00)            //  
 
#endif                                                        // HEADER_FILE_TI_LMP91400_REGISTER_SETTINGS_H