//******************************************************************************
//  Demo Application03 for MSP430/LMP91400 Interface Code Library v1.0
//  This example builds on Demo Application02: USB stack files are integrated
//
//   Vishy Natarajan
//   Texas Instruments Inc.
//   May 2012
//   Built with CCE Version: 4.2 and IAR Embedded Workbench Version:  5.3x
//******************************************************************************
/*  Copyright 2011-2012 Texas Instruments Incorporated. All rights reserved.

  IMPORTANT: Your use of this Software is limited to those specific rights
  granted under the terms of a software license agreement between the user who
  downloaded the software, his/her employer (which must be your employer) and
  Texas Instruments Incorporated (the "License"). You may not use this Software
  unless you agree to abide by the terms of the License. The License limits your
  use, and you acknowledge, that the Software may not be modified, copied or
  distributed unless embedded on a Texas Instruments microcontroller which is 
  integrated into your product. Other than for the foregoing purpose, you may 
  not use, reproduce, copy, prepare derivative works of, modify, distribute, 
  perform, display or sell this Software and/or its documentation for any 
  purpose.

  YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE
  PROVIDED �AS IS� WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
  INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE,
  NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL TEXAS
  INSTRUMENTS OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT,
  NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER LEGAL
  EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING BUT NOT
  LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR CONSEQUENTIAL
  DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF SUBSTITUTE GOODS,
  TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES (INCLUDING BUT NOT
  LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

  Should you have any questions regarding your right to use this Software,
  contact Texas Instruments Incorporated at www.TI.com.
*******************************************************************************/

#include <intrinsics.h>
#include <string.h>

#include <stdint.h>
#include <cstring>
#include <stdio.h>

#include "TI_LMP91400.h"
#include "TI_LMP91400_register_settings.h"
#include "TI_MSP430.h"
#include "TI_MSP430_hardware_board.h"
#include "TI_MSP430_spi.h"
#include "timer_queue.h"
#include "host_interface.h"

#include "USB_API/USB_Common/device.h"
#include "USB_API/USB_Common/types.h"               //Basic Type declarations
#include "USB_API/USB_Common/usb.h"                 //USB-specific functions

#include "F5xx_F6xx_Core_Lib/HAL_UCS.h"
#include "F5xx_F6xx_Core_Lib/HAL_PMM.h"

#include "USB_API/USB_CDC_API/UsbCdc.h"
#include "usbConstructs.h"
#include "USB_config/descriptors.h"

//******************************************************************************
#define MAX_STR_LENGTH 32

//******************************************************************************
void InitMCU(void);
void Init_Ports (void);
void Init_Clock (void);
void USBCommunicationTask(void);
void TI_LMP91400_reg_init(void);

volatile uint8_t LMP91400_ADCDataReady = 0;                                    // set to 1 in START interrupt service routine
volatile uint8_t LMP91400_XYBufferReady = 0;

volatile BYTE bCDCDataReceived_event = FALSE;   //Indicates data has been received without an open rcv operation


uint8_t cmdResponseString[MAX_STR_LENGTH] = "";



/*----------------------------------------------------------------------------*/
#define MAX_STOP_PULSES 6
#define ONE_100_uS 2400                   // 100us delay at 24MHz 
uint32_t err_count = 0;
extern uint16_t tstart;
extern uint16_t tstop[MAX_STOP_PULSES];
extern uint16_t tdelay[MAX_STOP_PULSES];
extern uint8_t nstop_pulse;
extern uint8_t timer_done_flag, pulse_count;
//******************************************************************************

void main(void)
{
  uint8_t i, timeout_count;
  
  WDTCTL = WDTPW+WDTHOLD;                                                      // Stop WDT 
  
  InitMCU();
  
  TI_LMP91400_LINK_LED_PxOUT |= TI_LMP91400_LINK_LED_PIN;                      // Set LINK_LED ON
  TI_LMP91400_LINK_LED_PxDIR |= TI_LMP91400_LINK_LED_PIN;                      // Set pin direction is output

  TI_LMP91400_OSCENABLE_PxOUT |= TI_LMP91400_OSCENABLE_PIN;                    // Set pin high: enable afe osc
  TI_LMP91400_OSCENABLE_PxDIR |= TI_LMP91400_OSCENABLE_PIN;                    // Set pin direction is output

  TI_LMP91400_RESET_PxOUT &= ~TI_LMP91400_RESET_PIN;                           // Reset low 
  TI_LMP91400_RESET_PxDIR |= TI_LMP91400_RESET_PIN;                            // Set pin direction is output
  
  TI_LMP91400_CHSEL_PxOUT &= ~TI_LMP91400_CHSEL_PIN;                           // channel select low 
  TI_LMP91400_CHSEL_PxDIR |= TI_LMP91400_CHSEL_PIN;                            // Set pin direction is output 
  
  TI_LMP91400_TRIGGER_PxOUT &= ~TI_LMP91400_TRIGGER_PIN;                       // channel select low 
  TI_LMP91400_TRIGGER_PxDIR |= TI_LMP91400_TRIGGER_PIN;                        // Set pin direction is output  

  // configure Port Pin to handle start pulse   
  TI_LMP91400_START_PxDIR &= ~TI_LMP91400_START_PIN;                           // Set up port pin for input
  TI_LMP91400_START_PxSEL |= TI_LMP91400_START_PIN;                            // select TA0 CCI0A
  
  // configure Port Pin to handle stop pulse 
  TI_LMP91400_STOP_PxDIR &= ~TI_LMP91400_STOP_PIN;                             // Set up port pin for input
  TI_LMP91400_STOP_PxSEL |= TI_LMP91400_STOP_PIN;                              // select TA0 CCI1A
   
  TI_LMP91400_ENABLE_PxOUT |= TI_LMP91400_ENABLE_PIN;                          // enable afe 
  TI_LMP91400_ENABLE_PxDIR |= TI_LMP91400_ENABLE_PIN;                          // Set pin direction is output
  
  TI_LMP91400_SPISetup();                                                      // Initilaize MSP430 SPI Block 
  // init capture time to continuously run
  timerA0_init();                                     
  
  // Reset the device
  TI_LMP91400_RESET_PxOUT |=  TI_LMP91400_RESET_PIN;
  __delay_cycles(5);
  TI_LMP91400_RESET_PxOUT &= ~TI_LMP91400_RESET_PIN;  
  
  // for testing
  TI_LMP91400_reg_init();

  while (1)
  {
//    __bis_SR_register(LPM0_bits + GIE);                                        // Enter LPM0, enable interrupts
    __no_operation();                                                          // For debugger 


#if 0
    // test code if single shot works 
    // clear error flag
    TI_LMP91400_SPIByteWriteReg(TI_LMP91400_ERROR_FLAGS_REG, 0x01);    
    nstop_pulse = 3;
    for(i=0; i<nstop_pulse; i++)
    {
      tstop[i] = 0;  
      tdelay[i] = 0;
    }    
    timer_done_flag = 0;
    // Trigger the device
    TI_LMP91400_TRIGGER_PxOUT |=  TI_LMP91400_TRIGGER_PIN;
    __delay_cycles(5);
    TI_LMP91400_TRIGGER_PxOUT &= ~TI_LMP91400_TRIGGER_PIN;
    timeout_count = 0;
    while (!timer_done_flag)
//    while (pulse_count <= nstop_pulse)
    {    
        __delay_cycles(ONE_100_uS);
        // wait max 2ms
        if (++timeout_count >200)
        {
          pulse_count = 0;
          // clear error flag
          // TI_LMP91400_SPIByteWriteReg(TI_LMP91400_ERROR_FLAGS_REG, 0x01);          
          break;
        }
    }
    // clear error flag
    TI_LMP91400_SPIByteWriteReg(TI_LMP91400_ERROR_FLAGS_REG, 0x01);    
    for(i=0; i<nstop_pulse; i++) 
    {
      if (tstart < tstop[i])
        tdelay[i] = tstop[i] - tstart;
      else
        tdelay[i] = (0x1000 + tstop[i]) - tstart;
    }
#endif
    __delay_cycles(240000);
    USBCommunicationTask();  
    __no_operation();                                                          // For debugger     
  }

}

//******************************************************************************
/**
* @brief  Local functions.                           
*/

/**
* @brief Function Name:  InitMCU.                                                
* @brief Description  :  Initializes the MSP430 peripherals and modules.
* @param parameters   :  none                                                   
* @return Value       :  none                                                   
*/   
//******************************************************************************
void InitMCU(void)
{
  
  __disable_interrupt();                                                       // Disable global interrupts 
//    Init_Ports();                                                              //Init ports (do first ports because clocks do change ports)
    SetVCore(3);
    Init_Clock();                                                              //Init clocks

#if 1
    USB_init();                 //Init USB

    USB_setEnabledEvents(
        kUSB_VbusOnEvent + kUSB_VbusOffEvent + kUSB_receiveCompletedEvent
        + kUSB_dataReceivedEvent + kUSB_UsbSuspendEvent + kUSB_UsbResumeEvent +
        kUSB_UsbResetEvent);

    //Check if we're already physically attached to USB, and if so, connect to it
    //This is the same function that gets called automatically when VBUS gets attached.
    if (USB_connectionInfo() & kUSB_vbusPresent){
        USB_handleVbusOnEvent();
    }
#endif
  __enable_interrupt();                                                        // enable global interrupts

}

//******************************************************************************
/**
* @brief Function Name: USBCommunicationTask     .                                             
* @brief Description  : Dumps data to the host over USB.
* @param parameters   : none                                                    
* @return Value       : none                                                    
*/   
//******************************************************************************
void USBCommunicationTask(void)
{
  WORD bytesSent, bytesReceived;
  uint16_t count;
  uint8_t send_error=0, receive_error=0, send_response, i;
  
        switch (USB_connectionState())
        {
            case ST_USB_DISCONNECTED:
//                __bis_SR_register(LPM3_bits + GIE);                     //Enter LPM3 w/interrupt
                _NOP();
                break;

            case ST_USB_CONNECTED_NO_ENUM:
                break;

            case ST_ENUM_ACTIVE:
                if (USBCDC_intfStatus(CDC0_INTFNUM,&bytesSent, &bytesReceived) & kUSBCDC_waitingForSend)
                    err_count++;
                // Exit LPM because of a data-receive event, and fetch the received data 
                if(bCDCDataReceived_event)
                {
                  bCDCDataReceived_event = FALSE;                                  // Clear flag early -- just in case execution breaks below because of an error
                  count = cdcReceiveDataInBuffer(cmdResponseString,MAX_STR_LENGTH,CDC0_INTFNUM);         // Count has the number of bytes received into dataBuffer    
                  send_response = handleHostCommand(cmdResponseString,count);
                  if (send_response)
                  {
                    if(cdcSendDataInBackground((BYTE*)cmdResponseString,MAX_STR_LENGTH,CDC0_INTFNUM,0))             // Send data to host
                    {
                      send_error = 1;                                            // Something went wrong -- exit
                      break;
                    }
                  }                  
                  for(i=0;i<MAX_STR_LENGTH;i++) 
                    cmdResponseString[i] = NULL;
                }       
                break;

            case ST_ENUM_SUSPENDED:
//                __bis_SR_register(LPM3_bits + GIE);             //Enter LPM3 until a resume or VBUS-off event
                break;

            case ST_ENUM_IN_PROGRESS:
                break;

            case ST_NOENUM_SUSPENDED:
//                __bis_SR_register(LPM3_bits + GIE);
                break;

            case ST_ERROR:
                _NOP();
                break;

            default:;
        }                                                                            //end of switch-case sentence
        if(send_error || receive_error)
        { 
          //TO DO: User can place code here to handle error
        }        
}
//******************************************************************************
#if 0
//******************************************************************************
/**
* @brief Function Name: Init_Clock .                                                
* @brief Description  : Initializes MSP430 clock module. 
* @param parameters   : none                                                    
* @return Value       : none                                                    
*/ 
//******************************************************************************
void Init_Clock(void)
    {
    //Initialization of clock module
    if (USB_PLL_XT == 2)
	{
	#if defined (__MSP430F552x) || defined (__MSP430F550x)
	    P5SEL |= 0x0C;                                      //enable XT2 pins for F5529
	#elif defined (__MSP430F563x_F663x)
	    P7SEL |= 0x0C;
	#endif

	#if 0
	    //use REFO for FLL and ACLK
	    UCSCTL3 = (UCSCTL3 & ~(SELREF_7)) | (SELREF__REFOCLK);
	    UCSCTL4 = (UCSCTL4 & ~(SELA_7)) | (SELA__REFOCLK);

	    //MCLK will be driven by the FLL (not by XT2), referenced to the REFO
	    Init_FLL_Settle(USB_MCLK_FREQ / 1000, USB_MCLK_FREQ / 32768);   //Start the FLL, at the freq indicated by the config
									    //constant USB_MCLK_FREQ
	    XT2_Start(XT2DRIVE_0);                                          //Start the "USB crystal"
	#endif
	// for USB2ANY which has XT2 crytstal = 24MHz
	UCSCTL4  = SELA_5 + SELS_5 + SELM_5;      // ACLK=XT2  SMCLK=XT2   MCLK=XT2
	XT2_Start(XT2DRIVE_3);
	}
    else
	{
	#if defined (__MSP430F552x) || defined (__MSP430F550x)
	    P5SEL |= 0x10;                         	  //enable XT1 pins
	#endif
	//Use the REFO oscillator to source the FLL and ACLK
	UCSCTL3 = SELREF__REFOCLK;
	UCSCTL4 = (UCSCTL4 & ~(SELA_7)) | (SELA__REFOCLK);

	//MCLK will be driven by the FLL (not by XT2), referenced to the REFO
	Init_FLL_Settle(USB_MCLK_FREQ / 1000, USB_MCLK_FREQ / 32768);   //set FLL (DCOCLK)

	XT1_Start(XT1DRIVE_0);   //Start the "USB crystal"
	}

    } //end Init_Clock()
#endif
//******************************************************************************
#if 1
void Init_Clock(void)
{
  // Enable XT2 XIN/XOUT Pins
  P5SEL |= 0x0C;                            // Select XIN, XOUT on P5.3 and P5.2
  UCSCTL6 &= ~XT2OFF;                       // Enable XT2  
  UCSCTL6 |= XT2DRIVE_3; 
  UCSCTL3 |= SELREF_2;                      // FLLref = REFO
                                            // Since LFXT1 is not used,
                                            // sourcing FLL with LFXT1 can cause
                                            // XT1OFFG flag to set

  // ACLK=REFO,SMCLK=DCO,MCLK=DCO
  UCSCTL4 = SELA__REFOCLK + SELS__DCOCLKDIV + SELM__DCOCLKDIV;
  UCSCTL0 = 0x0000;                                                            // Set lowest possible DCOx, MODx 
  
  // Loop until XT1,XT2 & DCO stabilizes
  do
  {
    UCSCTL7 &= ~(XT2OFFG + XT1LFOFFG + DCOFFG);
                                            // Clear XT2,DCO fault flags
    SFRIFG1 &= ~OFIFG;                      // Clear fault flags
  }while (SFRIFG1&OFIFG);                   // Test oscillator fault flag
  
  __bis_SR_register(SCG0);                                           // Disable the FLL control loop
  UCSCTL1 = DCORSEL_5;                                               // Select DCO range 16MHz operation
  UCSCTL2 |= 124;                                                    // Set DCO Multiplier for 8MHz
                                                                     // (N + 1) * FLLRef = Fdco
                                                                     // (249 + 1) * 32768 = 8MHz
                                                                     // (124 + 1) * 32768 = 4MHz
  __bic_SR_register(SCG0);                                           // Enable the FLL control loop

  // Worst-case settling time for the DCO when the DCO range bits have been
  // changed is n x 32 x 32 x f_MCLK / f_FLL_reference. See UCS chapter in 5xx
  // UG for optimization.
  // 32 x 32 x 8 MHz / 32,768 Hz = 250000 = MCLK cycles for DCO to settle
  __delay_cycles(250000);                                            // vishy:continue to keep 8MHz delay
  
                                            
  UCSCTL4 = SELA__DCOCLKDIV + SELS__XT2CLK + SELM__XT2CLK;                    // SMCLK=MCLK=XT2 = 24MHz

  // After changing UCSCTL4, loop again until XT1,XT2 & DCO stabilizes (Errat workaround?)
  do
  {
    UCSCTL7 &= ~(XT2OFFG + XT1LFOFFG + DCOFFG);
                                            // Clear XT2,DCO fault flags
    SFRIFG1 &= ~OFIFG;                      // Clear fault flags
  }while (SFRIFG1&OFIFG);                   // Test oscillator fault flag   
   
            
}
#endif
//******************************************************************************

/*  
 * ======== UNMI_ISR ========
 */
#pragma vector = UNMI_VECTOR
__interrupt VOID UNMI_ISR (VOID)
{
    switch (__even_in_range(SYSUNIV, SYSUNIV_BUSIFG ))
    {
        case SYSUNIV_NONE:
            __no_operation();
            break;
        case SYSUNIV_NMIIFG:
            __no_operation();
            break;
        case SYSUNIV_OFIFG:
            UCSCTL7 &= ~(DCOFFG + XT1LFOFFG + XT2OFFG); //Clear OSC flaut Flags fault flags
            SFRIFG1 &= ~OFIFG;                          //Clear OFIFG fault flag
            break;
        case SYSUNIV_ACCVIFG:
            __no_operation();
            break;
        case SYSUNIV_BUSIFG:
            SYSBERRIV = 0;                                      //clear bus error flag
            USB_disable();                                      //Disable
    }
}
//******************************************************************************
void TI_LMP91400_reg_init(void)
{
  TI_LMP91400_SPIByteWriteReg(TI_LMP91400_CONFIG0_REG, 0x26);                    
  TI_LMP91400_SPIByteWriteReg(TI_LMP91400_CONFIG1_REG, 0x40); // -> 44 to 40 (1stop)
  TI_LMP91400_SPIByteWriteReg(TI_LMP91400_CONFIG2_REG, 0x00); 
  TI_LMP91400_SPIByteWriteReg(TI_LMP91400_CONFIG3_REG, 0x0D);
  TI_LMP91400_SPIByteWriteReg(TI_LMP91400_CONFIG4_REG, 0x5E); // 5e (group) -> 1e (edge mode)
  TI_LMP91400_SPIByteWriteReg(TI_LMP91400_TOF1_REG, 0xA0);
  TI_LMP91400_SPIByteWriteReg(TI_LMP91400_TOF0_REG, 0x1E);
  TI_LMP91400_SPIByteWriteReg(TI_LMP91400_ERROR_FLAGS_REG, 0x01);
  TI_LMP91400_SPIByteWriteReg(TI_LMP91400_TIMEOUT_REG, 0x02);
  TI_LMP91400_SPIByteWriteReg(TI_LMP91400_CLOCK_RATE_REG, 0x01);
  
}
//******************************************************************************
//EOF