//******************************************************************************
//  Description:  This file contains functions that setups timerA0 for sampling.
//  Also, there are queue functions to queue and dequeue samples. Timer isr queues
//  the samples, while the usb communication task unqueues it to transmit out.
//  MSP430/LMP91400 Interface Code Library v1.0
// 
//
//   Vishy Natarajan
//   Texas Instruments Inc.
//   February 2012
//   Built with CCE Version: 4.2 and IAR Embedded Workbench Version:  5.3x
//******************************************************************************
/*  Copyright 2011-2012 Texas Instruments Incorporated. All rights reserved.

  IMPORTANT: Your use of this Software is limited to those specific rights
  granted under the terms of a software license agreement between the user who
  downloaded the software, his/her employer (which must be your employer) and
  Texas Instruments Incorporated (the "License"). You may not use this Software
  unless you agree to abide by the terms of the License. The License limits your
  use, and you acknowledge, that the Software may not be modified, copied or
  distributed unless embedded on a Texas Instruments microcontroller which is 
  integrated into your product. Other than for the foregoing purpose, you may 
  not use, reproduce, copy, prepare derivative works of, modify, distribute, 
  perform, display or sell this Software and/or its documentation for any 
  purpose.

  YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE
  PROVIDED �AS IS� WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
  INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE,
  NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL TEXAS
  INSTRUMENTS OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT,
  NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER LEGAL
  EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING BUT NOT
  LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR CONSEQUENTIAL
  DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF SUBSTITUTE GOODS,
  TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES (INCLUDING BUT NOT
  LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

  Should you have any questions regarding your right to use this Software,
  contact Texas Instruments Incorporated at www.TI.com.
*******************************************************************************/

#include <stdint.h>
#include <cstring>
//#include <cstdio>
#include <stdio.h>
#include "TI_LMP91400.h"
#include "TI_LMP91400_register_settings.h"
#include "TI_MSP430.h"
#include "TI_MSP430_hardware_board.h"
#include "TI_MSP430_spi.h"
#include "timer_queue.h"
/*----------------------------------------------------------------------------*/
#define INTERVAL_500us         3000                                            // SMCLK = 24MHz & %4
/*----------------------------------------------------------------------------*/
extern uint8_t nstop_pulse;
extern uint16_t tstart;
extern uint16_t tstop[];

uint8_t timer_done_flag = 0;
uint8_t pulse_count = 0;
//******************************************************************************

//------------------------------------------------------------------------------
//  void timerA0_init(void)
//
//  DESCRIPTION:
//  Initialize timer_A0 for capture    
//  Note: This function is for MSP430F5528 & might need modifications for other MSP430s
//------------------------------------------------------------------------------
void timerA0_init(void)
{
  TA0CCR0 = 0;      
  TA0CCR1 = 0;
//  overflow_count = 0;
  // stop pin as capture input
  TA0CCTL0 = CM_1 + SCS + CCIS_0 + CAP + CCIE;                                 // +ve edge; CCIA inp; captre mode; int
  // start pin as capture input
  TA0CCTL1 = CM_1 + SCS + CCIS_0 + CAP + CCIE;                                 // +ve edge; CCIA inp; captre mode; int
    
  TA0EX0 = TAIDEX_0;                                                           // No further divide
  TA0CTL = TASSEL_2 + TACLR + MC_2 + ID_0;                                     // SMCLK (24MHz), clear TAR, conts mode, divide by 1, no overflow intrpt TAIE      
    
}
//******************************************************************************
#pragma vector=TIMER0_A1_VECTOR
__interrupt void TIMER0_A1_ISR(void)
{
  switch(__even_in_range(TA0IV,14))
  {
    case 0: break;                  
    case 2:                                                                    // CCR1 interrupt
      {
        tstart = TA0CCR1;                                                      // save CCR1 value
        pulse_count = 0;                                                       // initialize pulse count
//            __bic_SR_register_on_exit(LPM0_bits);                              // Exit LPM0
             break;
      }
    case 4:  break;                         // CCR2 not used
    case 6:  break;                         // CCR3 not used
    case 8:  break;                         // CCR4 not used
    case 10: break;                         // CCR5 not used
    case 12: break;                         // Reserved not used
    case 14: break;                         // overflow interrupt
    default: break;
 }
}
//******************************************************************************
// Timer0 A0 interrupt service routine
//------------------------------------------------------------------------------
#pragma vector=TIMER0_A0_VECTOR
__interrupt void TIMER0_A0_ISR (void)
{

  tstop[pulse_count++] = TA0CCR0;                                         // Obtain CCR0 value
  // expected num of stop pulses =0, set done flag
  if (pulse_count == nstop_pulse) 
  {
    timer_done_flag = 1;
    pulse_count = 0;
  }
//  if (TA0CCTL0 & COV)
//    TA0CCTL0 &= ~COV;
            
//  __bic_SR_register_on_exit(LPM0_bits);                                        // Exit LPM0  
  
}

//******************************************************************************