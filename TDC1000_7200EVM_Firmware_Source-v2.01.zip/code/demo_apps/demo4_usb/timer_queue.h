//------------------------------------------------------------------------------
//  Description:  Header file for timer_queue.h
//
//  MSP430/LMP93601 Interface Code Library v1.1
//
//   Vishy Natarajan
//   Texas Instruments Inc.
//   February 2012
//   Built with CCE Version: 4.2 and IAR Embedded Workbench Version:  5.3x
//------------------------------------------------------------------------------
// Change Log:
//------------------------------------------------------------------------------
// Version:  1.00
// Comments: Initial Release Version
//------------------------------------------------------------------------------
#define MAX_STR_LENGTH 32

void timerA0_init(void);                                                       // initialize timerA0 to generate interrupt every sec


