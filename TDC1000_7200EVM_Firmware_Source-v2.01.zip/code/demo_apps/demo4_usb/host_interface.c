//******************************************************************************
//  Description:  This file contains functions that setups timerA0 for sampling.
//  Also, there are queue functions to queue and dequeue samples. Timer isr queues
//  the samples, while the usb communication task unqueues it to transmit out.
//  MSP430/LMP91400 Interface Code Library v1.0
// 
//
//   Vishy Natarajan
//   Texas Instruments Inc.
//   February 2012
//   Built with CCE Version: 4.2 and IAR Embedded Workbench Version:  5.3x
//******************************************************************************
/*  Copyright 2011-2012 Texas Instruments Incorporated. All rights reserved.

  IMPORTANT: Your use of this Software is limited to those specific rights
  granted under the terms of a software license agreement between the user who
  downloaded the software, his/her employer (which must be your employer) and
  Texas Instruments Incorporated (the "License"). You may not use this Software
  unless you agree to abide by the terms of the License. The License limits your
  use, and you acknowledge, that the Software may not be modified, copied or
  distributed unless embedded on a Texas Instruments microcontroller which is 
  integrated into your product. Other than for the foregoing purpose, you may 
  not use, reproduce, copy, prepare derivative works of, modify, distribute, 
  perform, display or sell this Software and/or its documentation for any 
  purpose.

  YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE
  PROVIDED �AS IS� WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
  INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE,
  NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL TEXAS
  INSTRUMENTS OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT,
  NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER LEGAL
  EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING BUT NOT
  LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR CONSEQUENTIAL
  DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF SUBSTITUTE GOODS,
  TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES (INCLUDING BUT NOT
  LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

  Should you have any questions regarding your right to use this Software,
  contact Texas Instruments Incorporated at www.TI.com.
*******************************************************************************/

#include <stdint.h>
#include <cstring>
//#include <cstdio>
#include <stdio.h>
#include "TI_LMP91400.h"
#include "TI_LMP91400_register_settings.h"
#include "TI_MSP430.h"
#include "TI_MSP430_hardware_board.h"
#include "TI_MSP430_spi.h"
#include "host_interface.h"

#define ONE_MS 24000                      // 1ms at 24MHz
#define ONE_100_uS 2400                   // 100us delay at 24MHz  
#define MAX_STOP_PULSES 6

extern uint8_t timer_done_flag;
extern uint8_t pulse_count;

void handle_reInit(uint8_t *pBuf, uint16_t pSize);
uint8_t char2nibble(uint8_t db);
uint8_t reg_local_copy[10] = {0x45, 0x40, 0x00, 0x03, 0x1F, 0x00, 0x00, 0x00, 0x19, 0x00};        // default settings
uint8_t LMP91400_address; 

uint16_t tstart;
uint16_t tstop[MAX_STOP_PULSES];
uint16_t tdelay[MAX_STOP_PULSES];
uint8_t nstop_pulse;


// Parse Command, then execute
uint8_t handleHostCommand(uint8_t *pBuf, uint16_t pSize)
{
  uint8_t host_response = 0;
  uint16_t word_data;
  uint8_t nxt_byte, byte_data;
  
  nxt_byte = char2nibble(pBuf[0]);
  nxt_byte = (nxt_byte << 4) + char2nibble(pBuf[1]);
  switch(nxt_byte)
  {
    case Command_LoopPacket:  
    {
      host_response = 1;
      break;
    }
    case Command_ReInit: 
    {
      handle_reInit(pBuf, pSize);
      host_response = 1;
      break;
    }    
    case Command_SPI_Byte_Write:
    {
      LMP91400_address = char2nibble(pBuf[2]);
      LMP91400_address = (LMP91400_address << 4) + char2nibble(pBuf[3]);
      
      byte_data = char2nibble(pBuf[4]);
      byte_data = (byte_data <<4) + char2nibble(pBuf[5]);
      TI_LMP91400_SPIByteWriteReg(LMP91400_address, byte_data);
      reg_local_copy[LMP91400_address] = byte_data;
      host_response = 1;
      break;
    }
    case Command_SPI_Byte_Read:
    {
      LMP91400_address = char2nibble(pBuf[2]);
      LMP91400_address = (LMP91400_address << 4) + char2nibble(pBuf[3]);
      byte_data = TI_LMP91400_SPIByteReadReg(LMP91400_address);
      pBuf[8] = byte_data;
      host_response = 1;
      break;
    }
    case Command_Start_TOF:
    {
      uint8_t i, j, timeout_count;
      
      nstop_pulse = char2nibble(pBuf[2]);
      nstop_pulse = (nstop_pulse << 4) + char2nibble(pBuf[3]);
      for(i=0; i<nstop_pulse; i++)
      {
        tstop[i] = 0;
        tdelay[i] = 0;
      }      
      timer_done_flag = 0;
      // Trigger the device
      TI_LMP91400_TRIGGER_PxOUT |=  TI_LMP91400_TRIGGER_PIN;
      __delay_cycles(5);
      TI_LMP91400_TRIGGER_PxOUT &= ~TI_LMP91400_TRIGGER_PIN;

      timeout_count = 0;
      while (!timer_done_flag)
//      while (pulse_count <= nstop_pulse)
      {
        
        __delay_cycles(ONE_100_uS);
        // wait max 2ms
        if (++timeout_count >200)
        {
          pulse_count = 0;
          // clear error flag
          // TI_LMP91400_SPIByteWriteReg(TI_LMP91400_ERROR_FLAGS_REG, 0x01);          
          break;
        }
      }
      pBuf[8] = tstart>>8;
      pBuf[9] = tstart;
      for(i=0,j=0; i<nstop_pulse; i++,j=j+2)
      {
        pBuf[10+j] = tstop[i]>>8;
        pBuf[10+j+1] = tstop[i];
      }                
      host_response = 1;
      break;
    }  
  case Command_Firmware_Version_Read:
    {
      pBuf[8] = Firmware_VersionA;
      pBuf[9] = Firmware_VersionB;
      pBuf[10] = Firmware_VersionC;
      pBuf[11] = Firmware_VersionD;
      host_response = 1;
      break;
    }
  case Command_LED_Toggle:
    {
      // toggle LED
      TI_LMP91400_LINK_LED_PxOUT ^= TI_LMP91400_LINK_LED_PIN;
      host_response = 1;
      break;
    }
  case Command_MSP430SPI_Config_Read:
    {
      pBuf[8] = UCB0CTL0 & 0xC0;
      pBuf[9] = UCB0BR0;
      pBuf[10] = UCB0BR1;
      host_response = 1;
      break;
    }
  case Command_MSP430SPI_Config_Write:
    {
      byte_data = char2nibble(pBuf[2]);
      byte_data = (byte_data <<4) + char2nibble(pBuf[3]); 
      byte_data &= 0xC0;                                                       // make sure only top 2 bits are valid
      // low byte first
      word_data = char2nibble(pBuf[6]);
      word_data = (word_data <<4) + char2nibble(pBuf[7]);
      // high byte next
      word_data = (word_data <<4) + char2nibble(pBuf[4]);
      word_data = (word_data <<4) + char2nibble(pBuf[5]);      
      if (word_data < 1)
        word_data = 1;
      UCB0CTL1 |= UCSWRST;                                                     // **Disable USCI state machine**
      UCB0CTL0 &= 0x3F;                                                        // update 
      UCB0CTL0 |= byte_data;
      UCB0BRW = word_data;                                                     // UCLK divider;
      UCB0CTL1 &= ~UCSWRST;                                                    // **Initialize USCI state machine**
      host_response = 1;
      break;
    }   
  }
  return (host_response);
}

void handle_reInit(uint8_t *pBuf, uint16_t pSize)
{
}
      
uint8_t char2nibble(uint8_t db)
{
  if ((db >= '0') && (db <= '9'))
    return (db-'0');
  else if ((db >= 'A') && (db <= 'F'))
    return (db-'A'+0xa);
  else if ((db >= 'a') && (db <= 'f'))
    return (db-'a'+0xa);
  else
    return (db);
}