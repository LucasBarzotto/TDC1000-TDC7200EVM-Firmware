//------------------------------------------------------------------------------
//  Description:  Header file for host_interface.h
//
//  MSP430/LMP93601 Interface Code Library v1.1
//
//   Vishy Natarajan
//   Texas Instruments Inc.
//   February 2012
//   Built with CCE Version: 4.2 and IAR Embedded Workbench Version:  5.3x
//------------------------------------------------------------------------------
// Change Log:
//------------------------------------------------------------------------------
// Version:  1.00
// Comments: Initial Release Version
//------------------------------------------------------------------------------

#define Firmware_VersionA 0
#define Firmware_VersionB 0                            // Major Rev: A + B
#define Firmware_VersionC 0
#define Firmware_VersionD 95                            // Minor Rev: C + D

uint8_t handleHostCommand(uint8_t *pBuf, uint16_t pSize);

//******************************************************************************
//Command and Packet definition
// 

#define Command_LoopPacket 0                // Loop back entire packet
											    // PacketBuffer[0],[1] Command
											    // 

#define Command_ReInit 1                    // Controls the firmware settings
											    // PacketBuffer[0],[1] Command
                                                                                            // PacketBuffer[1] Look for external trigger or not in continuous sampling 
                                                                                            // PacketBuffer[2]     													                                            	                                                	
                                                	                                                                                                    
#define Command_SPI_Byte_Write 2            // Writes data to SPI port
											    // PacketBuffer[0],[1] Command
											    // PacketBuffer[1],[2] SPI Address Byte											    
                                                                                            // PacketBuffer[3],[4] SPI Write Data Byte
  

#define Command_SPI_Byte_Read 3             // Read byte data from SPI port 
											    // PacketBuffer[0],[1] Command
											    // PacketBuffer[1],[2] SPI Address Byte
                                                                                            // PacketBuffer[8] Response: SPI Data Byte Read from device

#define Command_Start_TOF 5                 //Start TOF command 
											    // PacketBuffer[0],[1] Command
											    // PacketBuffer[2],[3] Expected num of stop pulses
                                                                             
                                                                                            // PacketBuffer[8] Response: start-stop1 data low byte 
                                                                                            // PacketBuffer[9] Response: start-stop1 data high byte
                                                                                            // PacketBuffer[10] Response: start-stop2 data low byte (only if numstop >= 2)
                                                                                            // PacketBuffer[11] Response: start-stop2 data high byte
                                                                                            // PacketBuffer[12] Response: start-stop3 data low byte (only if numch == 3)
                                                                                            // PacketBuffer[13] Response: start-stop3 data high byte


#define Command_SPI_Channel_Read_Continuous 6   // Read channel data from SPI port 
											    // PacketBuffer[0],[1] Command
											    // PacketBuffer[2],[3] SPI Address Byte
                                                                                            // PacketBuffer[4],[5] Num of channels (1 <= numch <= 3)
                                                                                            // PacketBuffer[8] Response: SPI ch1 data low byte 
                                                                                            // PacketBuffer[9] Response: SPI ch1 data high byte
                                                                                            // PacketBuffer[10] Response: SPI ch2 data low byte (only if numch >= 2)
                                                                                            // PacketBuffer[11] Response: SPI ch2 data high byte
                                                                                            // PacketBuffer[12] Response: SPI ch3 data low byte (only if numch == 3)
                                                                                            // PacketBuffer[13] Response: SPI ch3 data high byte

#define Command_End_Channel_Read_Continuous 7   // Read channel data from SPI port 
											    // PacketBuffer[0],[1] Command
											    // PacketBuffer[2],[3] SPI Address Byte
                                                                                            // PacketBuffer[8] Response: 

#define Command_Firmware_Version_Read 9     // Read firmware version 
											    // PacketBuffer[0],[1] Command
                                                                                            // PacketBuffer[8] Response: Firmware VersionA 
                                                                                            // PacketBuffer[9] Response: Firmware VersionB
                                                                                            // PacketBuffer[10] Response: Firmware VersionC 
                                                                                            // PacketBuffer[11] Response: Firmware VersionD

#define Command_LED_Toggle 10                // Toggle LED
											    // PacketBuffer[0],[1] Command
											    //

#define Command_MSP430SPI_Config_Read 11      // Read MSP430 SPI config info 
											    // PacketBuffer[0],[1] Command                            
                                                                                            // PacketBuffer[8] Response: SPI Clock Config   
                                                                                            // PacketBuffer[9] Response: SPI clock divider (low byte)
                                                                                            // PacketBuffer[10] Response: SPI clock divider (high byte)

#define Command_MSP430SPI_Config_Write 12      // Write MSP430 SPI config info 
											    // PacketBuffer[0],[1] Command
											    // PacketBuffer[2],[3] SPI Clock Config
                                                                                            // PacketBuffer[4],[5] SPI Clock divider low byte
                                                                                            // PacketBuffer[6],[7] SPI Clock divider high byte

