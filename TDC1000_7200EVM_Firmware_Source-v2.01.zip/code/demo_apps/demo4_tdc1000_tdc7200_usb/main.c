/* --COPYRIGHT--,BSD
* Copyright (c) 2014, Texas Instruments Incorporated
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
*
* * Redistributions of source code must retain the above copyright
* notice, this list of conditions and the following disclaimer.
*
* * Redistributions in binary form must reproduce the above copyright
* notice, this list of conditions and the following disclaimer in the
* documentation and/or other materials provided with the distribution.
*
* * Neither the name of Texas Instruments Incorporated nor the names of
* its contributors may be used to endorse or promote products derived
* from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
* THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
* PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
* EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
* OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
* WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
* --/COPYRIGHT--*/

#include <intrinsics.h>
#include <string.h>

#include <stdint.h>
#include <cstring>
#include <stdio.h>

#include "TI_TDC1000.h"
#include "TI_TDC7200.h"
#include "TI_TDC1000_register_settings.h"
#include "TI_MSP430.h"
#include "TI_MSP430_hardware_board.h"
#include "TI_MSP430_spi.h"
#include "timer_queue.h"
#include "host_interface.h"
#include "ports.h"
#include "tdc7200_calculation.h"
#include "uart_commn.h"
#include "msp430tdc_calculation.h"

#include "USB_API/USB_Common/device.h"
#include "USB_API/USB_Common/types.h"               //Basic Type declarations
#include "USB_API/USB_Common/usb.h"                 //USB-specific functions

#include "F5xx_F6xx_Core_Lib/HAL_UCS.h"
#include "F5xx_F6xx_Core_Lib/HAL_PMM.h"

#include "USB_API/USB_CDC_API/UsbCdc.h"
#include "usbConstructs.h"
#include "USB_config/descriptors.h"

//******************************************************************************
#define MAX_STR_LENGTH 32
//******************************************************************************
void InitMCU(void);
void Init_Clock (void);
void USBCommunicationTask(void);
void TI_TDC1000_reg_init(uint8_t);
void TI_TDC7200_reg_init(uint8_t);
extern void timer_microsec_delay(uint16_t);
extern void tdc_trigger_measure(void);
extern void MSP430Timer_tdc_trigger_measure(void);


// Globals & Externs
volatile uint8_t TDC1000_XYBufferReady = 0;
volatile uint8_t TDC1000_PQBufferReady = 0;
volatile BYTE bCDCDataReceived_event = FALSE;   //Indicates data has been received without an open rcv operation
WORD w;
uint8_t bufferX[BUF_LENGTH];
uint8_t bufferY[BUF_LENGTH];
uint8_t *mbuf=bufferX;
uint8_t *ubuf;

uint8_t bufferP[BUF_LENGTH];
uint8_t bufferQ[BUF_LENGTH];
uint8_t *nbuf=bufferP;
uint8_t *vbuf;

uint8_t cmdResponseString[MAX_STR_LENGTH] = "";
uint8_t single_shot_measure_state=0;
uint8_t tof_graph_state=0;
uint8_t continuous_trigger_state=0;
// by default disable power cycle
uint8_t tdc_power_cycle_flag=0;
uint8_t cpu_clk_period = 24;
uint16_t extosc_wakeup_period = 3000;
extern uint8_t TDC7200_reg_local_copy[];
extern uint8_t TDC1000_reg_local_copy[];
extern uint8_t outString[];
extern uint8_t TDC1000_MSP430Timer_TDC;
/*----------------------------------------------------------------------------*/

#define ONE_100_uS 2400                   // 100us delay at 24MHz 
uint32_t err_count = 0;
extern uint8_t timer_done_flag;
extern volatile uint8_t next_trigger_time;
extern uint8_t TDC1000_UART_Stream;
extern uint8_t TDC1000_MSP430Timer_TDC;
//******************************************************************************

void main(void)
{
  
  WDTCTL = WDTPW+WDTHOLD;                                                      // Stop WDT 
  
  // oscillator fail if LED keeps flashing after InitMCU     
  InitMCU();
  
  if (TDC1000_UART_Stream)
  {
    // Init UART
    InitUART();
    sprintf((char *)outString, "Hello World \r\n");
    putsUART((unsigned char *)outString,strlen((char *)outString));
  }
    
  TI_TDC7200_SPISetup();                                                       // Initilaize MSP430 SPI Block 

  TI_TDC1000_SPISetup();                                                      // Initilaize MSP430 SPI Block 
  
  // init 100ms interval timer (timer1)
  timer1_A0_init();

  // init timer0 A0 for programmable external osc wake up time
  // or when MSP430TIMER_TDC is true, init as capture timer to continuously run
  timer0_A0_init(); 
  
#if 1 // enable xclk 
  // 10/28: checked in v1.24 this piece of code is workng with red board
  // NOTE: When enabling this piece of code again make sure SMCLK is changed to 24MHz
  // Note reusing timer2 below for clock generation
  // use timer2 (A0 & A2 PWM) for clock generation (1 to 1.8MHz)
  cpu_clk_period = 18; // default xclk_freq = 24MHz/19 = 1.2632MHz
  TI_TDC1000_XCLK_PxDIR |= TI_TDC1000_XCLK_PIN;                                // Set pin direction is output
  // 11/4: Don't output the clock on the pin unless enabled by user by CPU_CLOCK enable command
  // TI_TDC1000_XCLK_PxSEL |= TI_TDC1000_XCLK_PIN;                                // Set options select
  TA2CCR0 = cpu_clk_period;                                                       // PWM Period
  TA2CCTL2 = OUTMOD_7;                                                         // CCR2 reset/set
  TA2CCR2 = (cpu_clk_period+1)/2;                                                 // CCR2 PWM duty cycle
  TA2CTL = TASSEL__SMCLK + MC_1 + TACLR;                                       // SMCLK, up mode, clear TAR 
#endif
  
  // init TDC1000
  TI_TDC1000_reg_init(REG_DEFAULT);
  // init TDC7200: register contents lost without enable
  if (!tdc_power_cycle_flag)
    TI_TDC7200_reg_init(REG_DEFAULT);
  
  next_trigger_time = 0;
  while (1)
  {
//    __bis_SR_register(LPM0_bits + GIE);                                        // Enter LPM0, enable interrupts
    __no_operation();                                                          // For debugger 
    USBCommunicationTask();
    if (next_trigger_time)
    {
      next_trigger_time = 0;
      if (TDC1000_MSP430Timer_TDC)
        MSP430Timer_tdc_trigger_measure();
      else
        tdc_trigger_measure();
      __no_operation();                                                        // For debugger     
    }
  }
}

//******************************************************************************
/**
* @brief  Local functions.                           
*/

/**
* @brief Function Name:  InitMCU.                                                
* @brief Description  :  Initializes the MSP430 peripherals and modules.
* @param parameters   :  none                                                   
* @return Value       :  none                                                   
*/   
//******************************************************************************
void InitMCU(void)
{
  
  __disable_interrupt();                                                       // Disable global interrupts 
    init_port_pins();                                                          //Init ports (do first ports because clocks do change ports)
    SetVCore(3);
    Init_Clock();                                                              //Init clocks

#if 1
    USB_init();                 //Init USB

    USB_setEnabledEvents(
        kUSB_VbusOnEvent + kUSB_VbusOffEvent + kUSB_receiveCompletedEvent
        + kUSB_dataReceivedEvent + kUSB_UsbSuspendEvent + kUSB_UsbResumeEvent +
        kUSB_UsbResetEvent);

    //Check if we're already physically attached to USB, and if so, connect to it
    //This is the same function that gets called automatically when VBUS gets attached.
    if (USB_connectionInfo() & kUSB_vbusPresent){
        USB_handleVbusOnEvent();
    }
#endif
  __enable_interrupt();                                                        // enable global interrupts

}

//******************************************************************************
/**
* @brief Function Name: USBCommunicationTask     .                                             
* @brief Description  : Dumps data to the host over USB.
* @param parameters   : none                                                    
* @return Value       : none                                                    
*/   
//******************************************************************************
void USBCommunicationTask(void)
{
  WORD bytesSent, bytesReceived;
  uint16_t count;
  uint8_t send_error=0, receive_error=0, send_response, i;
  
        switch (USB_connectionState())
        {
            case ST_USB_DISCONNECTED:
//                __bis_SR_register(LPM3_bits + GIE);                     //Enter LPM3 w/interrupt
                _NOP();
                break;

            case ST_USB_CONNECTED_NO_ENUM:
                break;

            case ST_ENUM_ACTIVE:
                if (USBCDC_intfStatus(CDC0_INTFNUM,&bytesSent, &bytesReceived) & kUSBCDC_waitingForSend)
                    err_count++;
                // Exit LPM because of a data-receive event, and fetch the received data 
                if(bCDCDataReceived_event)
                {
                  bCDCDataReceived_event = FALSE;                                  // Clear flag early -- just in case execution breaks below because of an error
                  count = cdcReceiveDataInBuffer(cmdResponseString,MAX_STR_LENGTH,CDC0_INTFNUM);         // Count has the number of bytes received into dataBuffer    
                  send_response = handleHostCommand(cmdResponseString,count);
                  if (send_response)
                  {
                    if(cdcSendDataInBackground((BYTE*)cmdResponseString,MAX_STR_LENGTH,CDC0_INTFNUM,0))             // Send data to host
                    {
                      send_error = 1;                                            // Something went wrong -- exit
                      break;
                    }
                  }                  
                  for(i=0;i<MAX_STR_LENGTH;i++) 
                    cmdResponseString[i] = NULL;
                } else if (((tof_graph_state == 1) || (single_shot_measure_state == 1))) 
                {
                  if (TDC1000_XYBufferReady)
                  {
                    TDC1000_XYBufferReady = 0;
                    if (cdcSendDataInBackground((BYTE*)ubuf,BUF_LENGTH,CDC0_INTFNUM,0))
                    {
                        bCDCDataReceived_event = FALSE;
                        USBCDC_abortSend(&w,CDC0_INTFNUM);              //Operation probably still open; cancel it
                    }
                    TI_TDC1000_LINK_LED_PxOUT ^= TI_TDC1000_LINK_LED_PIN;                      // Toggle LED
                    if (single_shot_measure_state == 1)
                    {
                      single_shot_measure_state = 0;   
                      TI_TDC1000_LINK_LED_PxOUT |= TI_TDC1000_LINK_LED_PIN;                        // Turn on LED
                    }
                    if (TDC1000_UART_Stream)
                    {
                      if (!TDC1000_MSP430Timer_TDC)
                        tdc7200_calc(ubuf);
                      else
                        msp430tdc_calc(ubuf);
                    }
                  }
                  if (TDC1000_PQBufferReady)
                  {
                    TDC1000_PQBufferReady = 0;
                    if (cdcSendDataInBackground((BYTE*)vbuf,BUF_LENGTH,CDC0_INTFNUM,0))
                    {
                        bCDCDataReceived_event = FALSE;
                        USBCDC_abortSend(&w,CDC0_INTFNUM);              //Operation probably still open; cancel it
                    }
                    TI_TDC1000_MEAS_LED_PxOUT ^= TI_TDC1000_MEAS_LED_PIN;                      // Toggle LED
                    if (single_shot_measure_state == 1)
                    {
                      single_shot_measure_state = 0;   
                      TI_TDC1000_MEAS_LED_PxOUT &= ~TI_TDC1000_MEAS_LED_PIN;                        // Turn on LED
                    }
                    if (TDC1000_UART_Stream)
                    {
                      if (!TDC1000_MSP430Timer_TDC)
                        tdc7200_calc(vbuf);
                      else
                        msp430tdc_calc(vbuf);
                    }
                  }
                }       
                break;

            case ST_ENUM_SUSPENDED:
//                __bis_SR_register(LPM3_bits + GIE);             //Enter LPM3 until a resume or VBUS-off event
                break;

            case ST_ENUM_IN_PROGRESS:
                break;

            case ST_NOENUM_SUSPENDED:
//                __bis_SR_register(LPM3_bits + GIE);
                break;

            case ST_ERROR:
                _NOP();
                break;

            default:;
        }                                                                            //end of switch-case sentence
        if(send_error || receive_error)
        { 
          //TO DO: User can place code here to handle error
        }        
}
//******************************************************************************
void Init_Clock(void)
{
  // Enable XT2 XIN/XOUT Pins
  P5SEL |= 0x0C;                            // Select XIN, XOUT on P5.3 and P5.2
  UCSCTL6 &= ~XT2OFF;                       // Enable XT2  
  UCSCTL6 |= XT2DRIVE_3; 
  UCSCTL3 |= SELREF_2;                      // FLLref = REFO
                                            // Since LFXT1 is not used,
                                            // sourcing FLL with LFXT1 can cause
                                            // XT1OFFG flag to set

  // ACLK=REFO,SMCLK=DCO,MCLK=DCO
  UCSCTL4 = SELA__REFOCLK + SELS__DCOCLKDIV + SELM__DCOCLKDIV;
  UCSCTL0 = 0x0000;                                                            // Set lowest possible DCOx, MODx 
  
  // Loop until XT1,XT2 & DCO stabilizes
  do
  {
    UCSCTL7 &= ~(XT2OFFG + XT1LFOFFG + DCOFFG);
                                            // Clear XT2,DCO fault flags
    SFRIFG1 &= ~OFIFG;                      // Clear fault flags
    TI_TDC1000_LINK_LED_PxOUT ^= TI_TDC1000_LINK_LED_PIN;                      // Toggle LED
  }while (SFRIFG1&OFIFG);                   // Test oscillator fault flag
  
  __bis_SR_register(SCG0);                                           // Disable the FLL control loop
  UCSCTL1 = DCORSEL_5;                                               // Select DCO range 16MHz operation
  UCSCTL2 |= 124;                                                    // Set DCO Multiplier for 8MHz
                                                                     // (N + 1) * FLLRef = Fdco
                                                                     // (249 + 1) * 32768 = 8MHz
                                                                     // (124 + 1) * 32768 = 4MHz
  __bic_SR_register(SCG0);                                           // Enable the FLL control loop

  // Worst-case settling time for the DCO when the DCO range bits have been
  // changed is n x 32 x 32 x f_MCLK / f_FLL_reference. See UCS chapter in 5xx
  // UG for optimization.
  // 32 x 32 x 8 MHz / 32,768 Hz = 250000 = MCLK cycles for DCO to settle
  __delay_cycles(250000);                                            // vishy:continue to keep 8MHz delay
  
  // 11/4: Dont' divide SMCLK by 2 /*UCSCTL5 |= DIVS__2;*/
  // 3/16: Select ACLK as XT2, divide ACLK by 2
  UCSCTL5 |= DIVA__2;
  UCSCTL4 = SELA__XT2CLK + SELS__XT2CLK + SELM__XT2CLK;                    // SMCLK=XT2, MCLK=XT2=24MHz

  // After changing UCSCTL4, loop again until XT1,XT2 & DCO stabilizes (Errat workaround?)
  do
  {
    UCSCTL7 &= ~(XT2OFFG + XT1LFOFFG + DCOFFG);
                                            // Clear XT2,DCO fault flags
    SFRIFG1 &= ~OFIFG;                      // Clear fault flags
    TI_TDC1000_LINK_LED_PxOUT ^= TI_TDC1000_LINK_LED_PIN;                      // Toggle LED
  }while (SFRIFG1&OFIFG);                   // Test oscillator fault flag   
  
  TI_TDC1000_LINK_LED_PxOUT |= TI_TDC1000_LINK_LED_PIN;                        // Turn on LED   
           
}
//******************************************************************************
void TI_TDC1000_reg_init(uint8_t type)
{
  if (type == REG_DEFAULT)
  {
#if 0  
    // 2MHz test cell
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_CONFIG0_REG, 0x24);                    
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_CONFIG1_REG, 0x41); // -> 44 to 41 (1stop)
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_CONFIG2_REG, 0x00); 
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_CONFIG3_REG, 0x0B);
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_CONFIG4_REG, 0x5F); // 5e (group) -> 1e (edge mode)
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_TOF1_REG, 0x80);
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_TOF0_REG, 0x1E);
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_ERROR_FLAGS_REG, 0x03);
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_TIMEOUT_REG, 0x3B);
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_CLOCK_RATE_REG, 0x01);
#endif
    // 1MHz test cell (new)
    // based on Matt's email on 04/28/2014
#if 1
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_CONFIG0_REG, 0x44); // 4pulses, divide by 8, 0x24 for 2MHz
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_CONFIG1_REG, 0x41); // -> 44 to 41 (1stop)
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_CONFIG2_REG, 0x00); // tx2 is 04, tx1 is 0
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_CONFIG3_REG, 0x05); // disable blanking, 320mv threshold
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_CONFIG4_REG, 0x5F); // 5e (group) -> 1e (edge mode)
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_TOF1_REG, 0x40);
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_TOF0_REG, 0x1E);
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_ERROR_FLAGS_REG, 0x03);
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_TIMEOUT_REG, 0x23);
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_CLOCK_RATE_REG, 0x01);
#endif
  } else if (type == REG_REINIT)
  {
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_CONFIG0_REG, TDC1000_reg_local_copy[0]);                    
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_CONFIG1_REG, TDC1000_reg_local_copy[1]);
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_CONFIG2_REG, TDC1000_reg_local_copy[2]); 
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_CONFIG3_REG, TDC1000_reg_local_copy[3]);
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_CONFIG4_REG, TDC1000_reg_local_copy[4]);
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_TOF1_REG, TDC1000_reg_local_copy[5]);
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_TOF0_REG, TDC1000_reg_local_copy[6]);
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_ERROR_FLAGS_REG, TDC1000_reg_local_copy[7]);
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_TIMEOUT_REG, TDC1000_reg_local_copy[8]);
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_CLOCK_RATE_REG, TDC1000_reg_local_copy[9]);    
  }
}
//******************************************************************************
void TI_TDC7200_reg_init(uint8_t type)
{
  if (type == REG_DEFAULT)
  {
    TI_TDC7200_SPIByteWriteReg(TI_TDC7200_CONFIG1_REG, 0x02); // Default Mode 2
    TI_TDC7200_SPIByteWriteReg(TI_TDC7200_CONFIG2_REG, 0x40); // cal2 period = 10 clocks
    TI_TDC7200_SPIByteWriteReg(TI_TDC7200_INTRPT_STATUS_REG, 0x07); // clear interrupt status
    TI_TDC7200_SPIByteWriteReg(TI_TDC7200_INTRPT_MASK_REG, 0x07); // interrupts enabled
    TI_TDC7200_SPIByteWriteReg(TI_TDC7200_COARSE_COUNTER_OVH_REG, 0xFF); // default
    TI_TDC7200_SPIByteWriteReg(TI_TDC7200_COARSE_COUNTER_OVL_REG, 0xFF); // default
    TI_TDC7200_SPIByteWriteReg(TI_TDC7200_CLOCK_COUNTER_OVH_REG, 0xFF); // default
    TI_TDC7200_SPIByteWriteReg(TI_TDC7200_CLOCK_COUNTER_OVL_REG, 0xFF); // default
    TI_TDC7200_SPIByteWriteReg(TI_TDC7200_CLOCK_COUNTER_STOP_MASKH_REG, 0x00); // default
    TI_TDC7200_SPIByteWriteReg(TI_TDC7200_CLOCK_COUNTER_STOP_MASKL_REG, 0x00); // default
  } else if (type == REG_REINIT)
  {
    TI_TDC7200_SPIByteWriteReg(TI_TDC7200_CONFIG1_REG, TDC7200_reg_local_copy[0]);                    
    TI_TDC7200_SPIByteWriteReg(TI_TDC7200_CONFIG2_REG, TDC7200_reg_local_copy[1]);
    TI_TDC7200_SPIByteWriteReg(TI_TDC7200_INTRPT_STATUS_REG, TDC7200_reg_local_copy[2]); 
    TI_TDC7200_SPIByteWriteReg(TI_TDC7200_INTRPT_MASK_REG, TDC7200_reg_local_copy[3]);
    TI_TDC7200_SPIByteWriteReg(TI_TDC7200_COARSE_COUNTER_OVH_REG, TDC7200_reg_local_copy[4]);
    TI_TDC7200_SPIByteWriteReg(TI_TDC7200_COARSE_COUNTER_OVL_REG, TDC7200_reg_local_copy[5]);
    TI_TDC7200_SPIByteWriteReg(TI_TDC7200_CLOCK_COUNTER_OVH_REG, TDC7200_reg_local_copy[6]);
    TI_TDC7200_SPIByteWriteReg(TI_TDC7200_CLOCK_COUNTER_OVL_REG, TDC7200_reg_local_copy[7]);
    TI_TDC7200_SPIByteWriteReg(TI_TDC7200_CLOCK_COUNTER_STOP_MASKH_REG, TDC7200_reg_local_copy[8]);
    TI_TDC7200_SPIByteWriteReg(TI_TDC7200_CLOCK_COUNTER_STOP_MASKL_REG, TDC7200_reg_local_copy[9]);    
  }

}
//******************************************************************************
/*  
 * ======== UNMI_ISR ========
 */
#pragma vector = UNMI_VECTOR
__interrupt void UNMI_ISR (void)
{
    switch (__even_in_range(SYSUNIV, SYSUNIV_BUSIFG ))
    {
        case SYSUNIV_NONE:
            __no_operation();
            break;
        case SYSUNIV_NMIIFG:
            __no_operation();
            break;
        case SYSUNIV_OFIFG:
            UCSCTL7 &= ~(DCOFFG + XT1LFOFFG + XT2OFFG); //Clear OSC flaut Flags fault flags
            SFRIFG1 &= ~OFIFG;                          //Clear OFIFG fault flag
            break;
        case SYSUNIV_ACCVIFG:
            __no_operation();
            break;
        case SYSUNIV_BUSIFG:
            SYSBERRIV = 0;                                      //clear bus error flag
            USB_disable();                                      //Disable
    }
}
//******************************************************************************
// ERRB interrupt service routine
#pragma vector=TI_TDC1000_ERRB_VECTOR
__interrupt void TI_TDC1000_ERR_PORTx(void)
{
    __no_operation();                                                          // Set Breakpoint here & see measured ain_plus 
    TI_TDC1000_ERRB_PxIFG &= ~TI_TDC1000_ERRB_PIN;                             //  IFG cleared
    // clear error flags and reset state machine
    TI_TDC1000_SPIByteWriteReg(TI_TDC1000_ERROR_FLAGS_REG, 0x03);
 //  __bic_SR_register_on_exit(LPM0_bits);                                        // Exit active CPU  
}
//******************************************************************************

//EOF
