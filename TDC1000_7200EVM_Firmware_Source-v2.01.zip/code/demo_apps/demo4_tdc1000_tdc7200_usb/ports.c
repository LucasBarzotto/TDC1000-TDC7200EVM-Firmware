/* --COPYRIGHT--,BSD
* Copyright (c) 2014, Texas Instruments Incorporated
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
*
* * Redistributions of source code must retain the above copyright
* notice, this list of conditions and the following disclaimer.
*
* * Redistributions in binary form must reproduce the above copyright
* notice, this list of conditions and the following disclaimer in the
* documentation and/or other materials provided with the distribution.
*
* * Neither the name of Texas Instruments Incorporated nor the names of
* its contributors may be used to endorse or promote products derived
* from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
* THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
* PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
* EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
* OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
* WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
* --/COPYRIGHT--*/
//******************************************************************************
#include <stdint.h>
#include "TI_TDC1000.h"
#include "TI_TDC7200.h"  
#include "TI_TDC1000_register_settings.h"
#include "TI_MSP430.h"
#include "TI_MSP430_hardware_board.h"
#include "ports.h"
//******************************************************************************
extern uint8_t tdc_power_cycle_flag;
//******************************************************************************
void init_port_pins(void)
{
  init_leds();
  init_osc_control();
  init_tdc1000_controls();
  init_tdc7200_controls();
  init_hv_driver_controls();
}
//******************************************************************************
void init_leds(void)
{
  TI_TDC1000_LINK_LED_PxOUT |= TI_TDC1000_LINK_LED_PIN;                        // Set LINK_LED ON
  TI_TDC1000_LINK_LED_PxDIR |= TI_TDC1000_LINK_LED_PIN;                        // Set pin direction is output

  TI_TDC1000_MEAS_LED_PxOUT &= ~TI_TDC1000_MEAS_LED_PIN;                       // Set MEAS_LED ON
  TI_TDC1000_MEAS_LED_PxDIR |= TI_TDC1000_MEAS_LED_PIN;                        // Set pin direction is output  
}
//******************************************************************************
void init_osc_control(void)
{
  if (tdc_power_cycle_flag)
    TI_TDC1000_OSCENABLE_PxOUT &= ~TI_TDC1000_OSCENABLE_PIN;                   // Set pin low: disable afe osc
  else
    TI_TDC1000_OSCENABLE_PxOUT |= TI_TDC1000_OSCENABLE_PIN;                    // Set pin high: enable afe osc    
  
  TI_TDC1000_OSCENABLE_PxDIR |= TI_TDC1000_OSCENABLE_PIN;                      // Set pin direction is output
  // use delay_cycles as MCU clock/timer init not done yet
  __delay_cycles(100000);
  
}
//******************************************************************************
void init_tdc1000_controls(void)
{
  TI_TDC1000_RESET_PxOUT &= ~TI_TDC1000_RESET_PIN;                             // Reset low 
  TI_TDC1000_RESET_PxDIR |= TI_TDC1000_RESET_PIN;                              // Set pin direction is output
  
  TI_TDC1000_CHSEL_PxOUT &= ~TI_TDC1000_CHSEL_PIN;                             // channel select low 
  TI_TDC1000_CHSEL_PxDIR |= TI_TDC1000_CHSEL_PIN;                              // Set pin direction is output 
  
  TI_TDC1000_TRIGGER_PxOUT &= ~TI_TDC1000_TRIGGER_PIN;                         // trigger pin low 
  TI_TDC1000_TRIGGER_PxDIR |= TI_TDC1000_TRIGGER_PIN;                          // Set pin direction is output    

  // configure Port Pin to handle start pulse   
  TI_TDC1000_START_PxDIR &= ~TI_TDC1000_START_PIN;                             // Set up port pin for input
  TI_TDC1000_START_PxSEL |= TI_TDC1000_START_PIN;                              // select TA0 CCI0A
  
  // configure Port Pin to handle stop pulse 
  TI_TDC1000_STOP_PxDIR &= ~TI_TDC1000_STOP_PIN;                               // Set up port pin for input
  TI_TDC1000_STOP_PxSEL |= TI_TDC1000_STOP_PIN;                                // select TA0 CCI1A

  // configure Port Pin to handle error 
  TI_TDC1000_ERRB_PxDIR &= ~TI_TDC1000_ERRB_PIN;                               // Set up port pin for input
  TI_TDC1000_ERRB_PxIES |= TI_TDC1000_ERRB_PIN;                                // Interrupt Edge Select
  TI_TDC1000_ERRB_PxIFG &= ~TI_TDC1000_ERRB_PIN;                               // Clear Interrupt Flag
  TI_TDC1000_ERRB_PxIE |= TI_TDC1000_ERRB_PIN;                                 // Enable Port interrupt

  if (tdc_power_cycle_flag)
    TI_TDC1000_ENABLE_PxOUT &= ~TI_TDC1000_ENABLE_PIN;                         // disable afe
  else
    TI_TDC1000_ENABLE_PxOUT |= TI_TDC1000_ENABLE_PIN;                          // enable afe
  TI_TDC1000_ENABLE_PxDIR |= TI_TDC1000_ENABLE_PIN;                            // Set pin direction is output
  // use delay_cycles as MCU clock/timer init not done yet
  __delay_cycles(1000);  

  // Reset the device
  TI_TDC1000_RESET_PxOUT |=  TI_TDC1000_RESET_PIN;
  __delay_cycles(5);
  TI_TDC1000_RESET_PxOUT &= ~TI_TDC1000_RESET_PIN;   
}
//******************************************************************************
void init_tdc7200_controls(void)
{
  // configure Port Pin to handle Interrupt Bar Output (INTB) from TDC7200
  TI_TDC7200_INTB_PxDIR &= ~TI_TDC7200_INTB_PIN;                               // Set up port pin for INTB
  TI_TDC7200_INTB_PxOUT |= TI_TDC7200_INTB_PIN;                                // INTB Input Pull up enable  
  TI_TDC7200_INTB_PxREN |= TI_TDC7200_INTB_PIN;                                // INTB Input Resistor enable  
  TI_TDC7200_INTB_PxIES |= TI_TDC7200_INTB_PIN;                                // Interrupt Edge Select
  TI_TDC7200_INTB_PxIFG &= ~TI_TDC7200_INTB_PIN;                               // Clear Interrupt Flag
//  TI_TDC7200_INTB_PxIE |= TI_TDC7200_INTB_PIN;                               // Enable Port interrupt

  if (tdc_power_cycle_flag)
    TI_TDC7200_ENABLE_PxOUT &= ~TI_TDC7200_ENABLE_PIN;                         // disable
  else
    TI_TDC7200_ENABLE_PxOUT |= TI_TDC7200_ENABLE_PIN;                          // Enable device
  TI_TDC7200_ENABLE_PxDIR |= TI_TDC7200_ENABLE_PIN;                            // Set pin direction output  
  // use delay_cycles as MCU clock/timer init not done yet
  __delay_cycles(50000); 
  
}
//******************************************************************************
void init_hv_driver_controls(void)
{
  // Setup HV boost enable pin
  TI_TDC1000_GPIO1_PxOUT &= ~TI_TDC1000_GPIO1_PIN;                             // enable pin low 
  TI_TDC1000_GPIO1_PxDIR |= TI_TDC1000_GPIO1_PIN;                              // Set pin direction is output  

  // Setup Amplifier enable pin
  TI_TDC1000_GPIO2_PxOUT &= ~TI_TDC1000_GPIO2_PIN;                             // enable pin low 
  TI_TDC1000_GPIO2_PxDIR |= TI_TDC1000_GPIO2_PIN;                              // Set pin direction is output  
  
  TI_TDC1000_GPIO7_PxOUT &= ~TI_TDC1000_GPIO7_PIN;                             // hv driver enable1 pin low 
  TI_TDC1000_GPIO7_PxDS |= TI_TDC1000_GPIO7_PIN;                               // Set pin drive strength high
  TI_TDC1000_GPIO7_PxDIR |= TI_TDC1000_GPIO7_PIN;                              // Set pin direction is output  

  TI_TDC1000_GPIO5_PxOUT &= ~TI_TDC1000_GPIO5_PIN;                             // hv driver enable2 pin low
  TI_TDC1000_GPIO5_PxDS |= TI_TDC1000_GPIO5_PIN;                               // Set pin drive strength high
  TI_TDC1000_GPIO5_PxDIR |= TI_TDC1000_GPIO5_PIN;                              // Set pin direction is output  
  
}
//******************************************************************************
