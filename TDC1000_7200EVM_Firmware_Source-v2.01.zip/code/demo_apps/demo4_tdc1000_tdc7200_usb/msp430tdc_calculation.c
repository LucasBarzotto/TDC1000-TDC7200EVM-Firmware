/* --COPYRIGHT--,BSD
* Copyright (c) 2014, Texas Instruments Incorporated
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
*
* * Redistributions of source code must retain the above copyright
* notice, this list of conditions and the following disclaimer.
*
* * Redistributions in binary form must reproduce the above copyright
* notice, this list of conditions and the following disclaimer in the
* documentation and/or other materials provided with the distribution.
*
* * Neither the name of Texas Instruments Incorporated nor the names of
* its contributors may be used to endorse or promote products derived
* from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
* THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
* PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
* EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
* OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
* WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
* --/COPYRIGHT--*/
//******************************************************************************
#include <stdint.h>
#include <cstring>
#include <stdio.h>
#include "TI_TDC1000.h"
#include "TI_TDC7200.h"  
#include "TI_TDC1000_register_settings.h"
#include "TI_MSP430.h"
#include "TI_MSP430_hardware_board.h"
#include "TI_MSP430_spi.h"
#include "timer_queue.h"
#include "msp430tdc_calculation.h"
#include "uart_commn.h"

//******************************************************************************
// MSP430 Start/Stop Capture Timer TA0 Clock Period in ns
#define MSP430TIMER_TDC_CLK_PERIOD 1000/12.0

extern uint8_t outString[];
 
//------------------------------------------------------------------------------
void msp430tdc_calc(uint8_t *buf)
{
  uint16_t tst, tsp;
  uint16_t ovf;
  float st2sp;
  
  tst = buf[0] + (buf[1] << 8);
  tsp = buf[2] + (buf[3] << 8);
  ovf = buf[4];
#if 0  
  if (ovf)
  {
    // if overflow happens just after start crosses 65536
    // then don't count overflow, 100 is just arbitrary
    if (tst < 10)
      ovf--;
    // if overflow happens just before stop crosses 65536
    // then don't count overflow   
    if (ovf)
      if (tsp >= 65526)
        ovf--;
  } 
#endif
  st2sp = (((ovf * 65536) + tsp) - tst)* MSP430TIMER_TDC_CLK_PERIOD;
  
  sprintf((char *)outString, "Start_to_Stop1: %4.6f \r\n", st2sp);  
  putsUART((unsigned char *)outString,strlen((char *)outString));

}
//******************************************************************************


