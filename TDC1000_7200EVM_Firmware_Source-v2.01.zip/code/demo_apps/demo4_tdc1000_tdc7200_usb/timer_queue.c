/* --COPYRIGHT--,BSD
* Copyright (c) 2014, Texas Instruments Incorporated
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
*
* * Redistributions of source code must retain the above copyright
* notice, this list of conditions and the following disclaimer.
*
* * Redistributions in binary form must reproduce the above copyright
* notice, this list of conditions and the following disclaimer in the
* documentation and/or other materials provided with the distribution.
*
* * Neither the name of Texas Instruments Incorporated nor the names of
* its contributors may be used to endorse or promote products derived
* from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
* THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
* PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
* EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
* OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
* WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
* --/COPYRIGHT--*/

#include <stdint.h>
#include <cstring>
//#include <cstdio>
#include <stdio.h>
#include "TI_TDC1000.h"
#include "TI_TDC7200.h"  
#include "TI_TDC1000_register_settings.h"
#include "TI_MSP430.h"
#include "TI_MSP430_hardware_board.h"
#include "TI_MSP430_spi.h"
#include "timer_queue.h"
#include "host_interface.h"
/*----------------------------------------------------------------------------*/
#define INTERVAL_100ms         37500                                           // SMCLK = 24MHz & /64
/*----------------------------------------------------------------------------*/

extern uint8_t bufferX[], bufferY[];
extern uint8_t *mbuf, *ubuf;
extern uint8_t bufferP[], bufferQ[];
extern uint8_t *nbuf, *vbuf;
extern volatile uint8_t TDC1000_XYBufferReady;
extern volatile uint8_t TDC1000_PQBufferReady;
extern uint8_t single_shot_measure_state;
extern uint8_t tof_graph_state;
extern uint8_t continuous_trigger_state;
extern uint8_t tdc_power_cycle_flag;
extern uint8_t TDC7200_reg_local_copy[];
extern uint8_t double_resolution_flag;
extern uint8_t TDC1000_MSP430Timer_TDC;

extern void TI_TDC7200_reg_init(void);
extern uint8_t get_TDC1000_mode(void);
extern void reset_device(uint8_t);

uint16_t tstart, tstop;

uint8_t timer_done_flag = 0;
uint16_t timer_trigger_freq = 1;
uint16_t fwd2rev_flow_delay = 1;
volatile uint8_t next_trigger_time = 0;
uint8_t measure_one_temp = 0;
uint8_t interleaved_temp_measure = 0;
uint16_t count_per_temp = 0;
uint16_t nsamp_done = 0;
volatile uint8_t overflow_count = 0;
uint8_t ovf_final;

uint8_t TDC1000_Impedance_Matching_Enable = 0;
uint8_t TDC1000_HV_Boost_Power_Enable = 0;
uint8_t TDC1000_HV_Driver_Enable1 = 0;
uint8_t TDC1000_HV_Driver_Enable2 = 0;
uint16_t TDC1000_HV_Boost_Power_Enable_Period = 15000;
uint16_t TDC1000_HV_Driver_Enable1_Period = 0;
uint16_t TDC1000_HV_Driver_Enable2_Period = 0;

// TDC downstream controls: enable/disable, echo qual thld, pga gain
uint8_t TDC1000_Downstream_Control=0;
uint8_t tdc_ds_eq_thld=0;
uint8_t tdc_ds_pga_gain=0;


void timer_microsec_delay(uint16_t);
void tdc_trigger_measure(void);
void MSP430Timer_tdc_trigger_measure(void);
void handle_hv_driver_pre_fire(void);
void handle_hv_driver_post_fire(void);
//******************************************************************************

//******************************************************************************

//------------------------------------------------------------------------------
//  void timerA0_init(void)
//
//  DESCRIPTION:
//  Initialize timer0_A0 for Accurate Timer Microsecond Delay    
//  Note: This function is for MSP430F5528 & might need modifications for other MSP430s
//------------------------------------------------------------------------------
void timer0_A0_init(void)
{
  if (!TDC1000_MSP430Timer_TDC)
  { 
    // clear the control registers to reset state
    TA0CCTL0 = 0;
    TA0CCTL1 = 0;
    TA0CTL = 0;
    
    // set initial timeout period of 3000us: equal to extl osc max wakeup period
    TA0CCR0 = 5000;     
    // disable timer0 A0 interrupt
    TA0CCTL0 &= ~CCIE;                                                             
    // Note: TACLR clears both counter and clock divider: setup divider later                                                        
    // SMCLK (24MHz), clear TAR, stop mode, divide by 8, no overflow intrpt TAIE
    TA0CTL |= TACLR;
    TA0CTL = TASSEL__SMCLK + MC_0 + ID_3; // choose 8 as SMCLK is now 24MHz  
    // Further divide by 3: 1us timer clock period
    TA0EX0 = TAIDEX_2;
  } else
  {
    TA0CCR0 = 0;      
    TA0CCR1 = 0;
    //  overflow_count = 0;
    // stop pin as capture input (don't enable interrupt yet)
    TA0CCTL0 = CM_1 + SCS + CCIS_0 + CAP;                                        // +ve edge; CCIA inp; captre mode
    // start pin as capture input (don't enable interrupt yet)
    TA0CCTL1 = CM_1 + SCS + CCIS_0 + CAP;                                        // +ve edge; CCIA inp; captre mode
    
    TA0EX0 = TAIDEX_0;                                                           // No further divide
    TA0CTL = TASSEL_2 + TACLR + MC_2 + ID_1;                                     // SMCLK (24MHz), clear TAR, conts mode, divide by 2, no overflow intrpt TAIE      

    // make sure interrupts are disabled
    TA0CCTL0 &= ~CCIE;
    TA0CCTL1 &= ~CCIE;
    TA0CTL &= ~TAIE;    
  }
    
}
//******************************************************************************
// Timer0 A0 interrupt service routine
//------------------------------------------------------------------------------
#pragma vector=TIMER0_A0_VECTOR
__interrupt void TIMER0_A0_ISR (void)
{
  timer_done_flag = 1; 
  if (TDC1000_MSP430Timer_TDC)
  {
    tstop = TA0CCR0;                                                           // save CCR0
    ovf_final = overflow_count;
#if 0
    // make sure interrupts are disabled
    // as we want to freeze overflow_count 
    // any overflow before this stop should be included
    if ((TAIFG) && (tstop <= 100))
        ovf_final = overflow_count+1;
#endif
    
    // handle case where overflow is not registered & tstop is smaller
    // than tstart (this was observed when tstop is 0,1 or 2 (very small value)
    if ((ovf_final == 0) && (tstop <= tstart))
       ovf_final++;
    TA0CTL &= ~(TAIE + TAIFG);
    TA0CCTL0 &= ~(CCIE + CCIFG);
    TA0CCTL1 &= ~(CCIE + CCIFG);
       
  }
//  __bic_SR_register_on_exit(LPM0_bits);                                      // Exit LPM0  
  
}
//******************************************************************************
#pragma vector=TIMER0_A1_VECTOR
__interrupt void TIMER0_A1_ISR(void)
{
  switch(__even_in_range(TA0IV,14))
  {
    case 0: break;                  
    case 2:                                                                    // CCR1 interrupt
      {
        tstart = TA0CCR1;                                                      // save CCR1 value
        overflow_count = 0;                                                    // initialize pulse count
        // ignore any overflow before start
        if ((TAIFG) && (tstart <= 100))
           TA0CTL &= ~TAIFG;

//            __bic_SR_register_on_exit(LPM0_bits);                              // Exit LPM0
             break;
      }
    case 4:  break;                         // CCR2 not used
    case 6:  break;                         // CCR3 not used
    case 8:  break;                         // CCR4 not used
    case 10: break;                         // CCR5 not used
    case 12: break;                         // Reserved not used
    case 14:                                // overflow interrupt
             TA0CTL &= ~TAIFG;
             overflow_count++;
             break;
    default: break;
 }
}
//******************************************************************************
//------------------------------------------------------------------------------
//  void timer1_A0_init(void)
//
//  DESCRIPTION:
//  Initialize timer1_A0 for timed AFE trigger (Trigger Update Freq of GUI)    
//  Note: This function is for MSP430F5528 & might need modifications for other MSP430s
//------------------------------------------------------------------------------
void timer1_A0_init(void)
{
  TA1CCR0 = INTERVAL_100ms;      
  // enable timer interrupt
  TA1CCTL0 |= CCIE;                                                            // TA1CCR0 interrupt enabled       
  // Note: TACLR clears both counter and clock divider: setup divider later
  TA1CTL |= TACLR;
  TA1CTL = TASSEL__SMCLK + MC_1 + ID_3;                                          // SMCLK (24MHz), clear TAR, conts mode, divide by 4, no overflow intrpt TAIE 
  TA1EX0 = TAIDEX_7;                                                           // further divide by 8
    
}
//******************************************************************************
// Timer1 A0 interrupt service routine
//------------------------------------------------------------------------------
#pragma vector=TIMER1_A0_VECTOR
__interrupt void TIMER1_A0_ISR (void)
{
  static uint8_t delay_sec=0;
  
  delay_sec++;
  if (delay_sec > timer_trigger_freq)
  {
    next_trigger_time = 1;
    delay_sec = 0; 
  }
// __bic_SR_register_on_exit(LPM0_bits);                                       // Exit LPM0  
  
}
//******************************************************************************
void timer_microsec_delay(uint16_t us)
{
  uint16_t save_delay;
  uint16_t i;
  if (TDC1000_MSP430Timer_TDC)
  {
    if (us == 0)
      us = 1000;
    // using software based delay
    for(i=0; i<us; i++)
      __delay_cycles(24);   
  } else
  {
    save_delay = TA0CCR0;
    if (us)
      TA0CCR0 = us;
    timer_done_flag = 0;
    TA0CCTL0 |= CCIE;                                                            // enable timer0A0 int
    // since we are calling from an isr...
    //__enable_interrupt();
    // SMCLK (24MHz), clear TAR, up mode, divide by 8, no overflow intrpt TAIE
    TA0CTL |= MC_1;
    // wait for timer programmed delay
    while (!timer_done_flag);
    // SMCLK (24MHz), clear TAR, stop mode, divide by 8, no overflow intrpt TAIE
    TA0CTL &= ~MC_1;
    // Restore delay
    TA0CCR0 = save_delay;  
  }
}
//******************************************************************************
void tdc_trigger_measure(void)
{
  uint8_t cfg2, save1, save2;
  uint8_t save_cfg3, save_tof1;
  uint16_t i;
  
  if ((continuous_trigger_state == 1) || (tof_graph_state == 1) || (single_shot_measure_state == 1))
  {
    uint8_t byte_data;
    uint32_t tout = 0;
    //uint8_t cfg2;
    
    
    // Set Impedance Matching Control before upstream measurement 
    // Note: GPIO1 pin is reused between impedance matching and HV Boost Power Enable
    if (TDC1000_Impedance_Matching_Enable == 1)  
    {
      TI_TDC1000_GPIO1_PxOUT |= TI_TDC1000_GPIO1_PIN;
      // For impedance matching to work, Bahram wants some delay before start
      timer_microsec_delay(2000);    
    }
    
    if (tdc_power_cycle_flag)
    {
      // enable external osc before starting measurement
      TI_TDC1000_OSCENABLE_PxOUT |= TI_TDC1000_OSCENABLE_PIN;                    // Set pin high: enable afe osc
      
      // use default delay if input is 0
      timer_microsec_delay(10000);
        
      // enable AFE & wait wakeup period of atleast 5us
      TI_TDC1000_ENABLE_PxOUT |= TI_TDC1000_ENABLE_PIN;                          // enable afe
      __delay_cycles(120);
    
      // Enable device
      TI_TDC7200_ENABLE_PxOUT |= TI_TDC7200_ENABLE_PIN;                            
      
      // wait for TDC7200 wakeup delay
      timer_microsec_delay(TDC7200_WAKEUP_PERIOD * 2);
    
      // read config1 register - when power cycling use local saved data
      byte_data = TDC7200_reg_local_copy[TI_TDC7200_CONFIG1_REG];
      // init TDC7200 with local saved data
      TI_TDC7200_SPIAutoIncWriteReg(TI_TDC7200_CONFIG1_REG, TDC7200_reg_local_copy, 10);
      
    } else
    {
      // read config1 register
      byte_data = TI_TDC7200_SPIByteReadReg(TI_TDC7200_CONFIG1_REG);      
    }

    if (double_resolution_flag)
    {
      uint8_t reg_address;
      uint8_t all_data[2];
        
      reg_address = 0x0b;      
      all_data[0] = 0;
      all_data[1] = 0x01;
      TI_TDC7200_SPIAutoIncWriteReg(reg_address, all_data, 2);        
    }    

    if (interleaved_temp_measure == 1)
    {
      measure_one_temp = 0;
      if (nsamp_done == count_per_temp)
      {
        // config2 for temp_measurement
        save1 = cfg2 = TI_TDC1000_SPIByteReadReg(TI_TDC1000_CONFIG2_REG);
        cfg2 |= 0x40;
        TI_TDC1000_SPIByteWriteReg(TI_TDC1000_CONFIG2_REG, cfg2);
	
        // Due to temp glitch bug tdc1000 config3 always be rtd1-rtd2
	// TI_TDC1000_SPIByteWriteReg(TI_TDC1000_CONFIG3_REG, 0x40);
        
        // config TDC7200 for 5 stops
        save2 = cfg2 = TI_TDC7200_SPIByteReadReg(TI_TDC7200_CONFIG2_REG);
        cfg2 &= 0xC0; // clear last 6 bits: both num stops and avgng cycles
        cfg2 |= 0x04;
        TI_TDC7200_SPIByteWriteReg(TI_TDC7200_CONFIG2_REG, cfg2);
	
        // set temp_measure_state for this measurement (reset once data sent out)
	measure_one_temp = 1;
        nsamp_done = 0;
        
      } else
	nsamp_done++;    
    }
    // Handle HV Driver Enable Command
    handle_hv_driver_pre_fire();

#if 0    
    // Set Impedance Matching Control before upstream measurement 
    // Note: GPIO1 pin is reused between impedance matching and HV Boost Power Enable
    if (TDC1000_Impedance_Matching_Enable == 1)  
    {
      TI_TDC1000_GPIO1_PxOUT |= TI_TDC1000_GPIO1_PIN;
      // For impedance matching to work, Bahram wants some delay before start
      timer_microsec_delay(100);    
    }    
#endif

    // set start measurement bit & use default mode or set by user
    byte_data |= 0x01;
    TI_TDC7200_SPIByteWriteReg(TI_TDC7200_CONFIG1_REG, byte_data);
    
    // Trigger the AFE (by CPU also)
    // depending on jumper setting either TDC7200 or CPU wil trigger the AFE
    TI_TDC1000_TRIGGER_PxOUT |=  TI_TDC1000_TRIGGER_PIN;
    __delay_cycles(5);
    TI_TDC1000_TRIGGER_PxOUT &= ~TI_TDC1000_TRIGGER_PIN;
   
    // Handle HV Driver Enable Command
    handle_hv_driver_post_fire();
   
    //wait for INTB pin to go low
    while(TI_TDC7200_INTB_PxIN & TI_TDC7200_INTB_PIN)
    {
      tout++;
      // 1us delay below at 24MHz master clock
      __delay_cycles(24);
      // tout defautl is 20000, wait atleast 200ms and timeout
      if (tout >= TIMEOUT_VALUE)
      {
        // clear error flags and reset state machine
        TI_TDC1000_SPIByteWriteReg(TI_TDC1000_ERROR_FLAGS_REG, 0x03);
        reset_device(TDC1000);
        reset_device(TDC7200);
        break;
      }
    }
      
    TI_TDC7200_SPIAllReadReg(mbuf);
    //TI_TDC7200_SPIAllReadRegNoAutoInc(mbuf);
    
    // indicate this is a temperature packet: using last byte 
    if (measure_one_temp == 1)
      mbuf[39] |= 0xA5;
    else // normal TOF packet
      mbuf[39] = 0x0;
    
    ubuf = mbuf;
    if (mbuf == bufferX)
      mbuf = bufferY;
    else
      mbuf = bufferX; 
    if ((tof_graph_state == 1) || (single_shot_measure_state == 1))
    {      
      TDC1000_XYBufferReady = 1;
    }
    // TDC1000 Enable Pin toggling effect: during AUTO_FLOW state m/c is reset
    // need to make downstream measurement also before shutting down
    if ((measure_one_temp !=1) && (get_TDC1000_mode() == AUTO_FLOW))
    {

      // Clear Impedance Matching Control before downstream measurement 
      // Note: GPIO1 pin is reused between impedance matching and HV Boost Power Enable
      if (TDC1000_Impedance_Matching_Enable == 1)  
      {
        TI_TDC1000_GPIO1_PxOUT &= ~TI_TDC1000_GPIO1_PIN;
        // For impedance matching to work, Bahram wants some delay before start
        timer_microsec_delay(100);    
      } 
      
      // Give delay for transducer to settle down:100us
      // after experiments in v1.04, determined 100us is optimal
      // 10/31: make it a ms 
      // For Gas make this 16ms; 2/12: Make it programmable
      // Flow Delay is percentage of Timer Trigger Freq (which is 100ms multiple)
      for (i=(timer_trigger_freq+1)*(fwd2rev_flow_delay+1);i>0;i--)
        timer_microsec_delay(1000);

      // Handle HV Driver Enable Command
      handle_hv_driver_pre_fire(); 

#if 0      
      // Clear Impedance Matching Control before downstream measurement 
      // Note: GPIO1 pin is reused between impedance matching and HV Boost Power Enable
      if (TDC1000_Impedance_Matching_Enable == 1)  
      {
        TI_TDC1000_GPIO1_PxOUT &= ~TI_TDC1000_GPIO1_PIN;
        // For impedance matching to work, Bahram wants some delay before start
        timer_microsec_delay(100);    
      }
#endif
      
      // set downstream controls: echo qual threshold and pga gain
      if (TDC1000_Downstream_Control == 1)
      {
        uint8_t rd;
        // read upstream echo qual thld
        save_cfg3 = rd = TI_TDC1000_SPIByteReadReg(TI_TDC1000_CONFIG3_REG);
        // clear 3 bits & set it to new value
        rd &= 0xF8;
        rd |= tdc_ds_eq_thld;
        TI_TDC1000_SPIByteWriteReg(TI_TDC1000_CONFIG3_REG, rd);
        // read upstream pga gain
        save_tof1 = rd = TI_TDC1000_SPIByteReadReg(TI_TDC1000_TOF1_REG);
        // clear top 3 bits & set it to new value
        rd &= 0x1F;
        rd |= tdc_ds_pga_gain;
        TI_TDC1000_SPIByteWriteReg(TI_TDC1000_TOF1_REG, rd);        
      }
      
      // need to complete both up and downstream measurements before power cycle
      // set start measurement bit & use default mode or set by user
      byte_data |= 0x01;
      TI_TDC7200_SPIByteWriteReg(TI_TDC7200_CONFIG1_REG, byte_data);
    
      // Trigger the AFE (by CPU also)
      // depending on jumper setting either TDC7200 or CPU wil trigger the AFE
      TI_TDC1000_TRIGGER_PxOUT |=  TI_TDC1000_TRIGGER_PIN;
      __delay_cycles(5);
      TI_TDC1000_TRIGGER_PxOUT &= ~TI_TDC1000_TRIGGER_PIN;
      
      // Handle HV Driver Enable Command
      handle_hv_driver_post_fire();      
   
      //wait for INTB pin to go low
      while(TI_TDC7200_INTB_PxIN & TI_TDC7200_INTB_PIN)
      {
        tout++;
        // 1us delay below at 24MHz master clock
        __delay_cycles(24);
        // tout defautl is 20000, wait atleast 200ms and timeout
        if (tout >= TIMEOUT_VALUE)
        {
          // clear error flags and reset state machine
          TI_TDC1000_SPIByteWriteReg(TI_TDC1000_ERROR_FLAGS_REG, 0x03);
          reset_device(TDC1000);
          reset_device(TDC7200);   
          break;
        }
      }
      TI_TDC7200_SPIAllReadReg(nbuf);
      //TI_TDC7200_SPIAllReadRegNoAutoInc(nbuf);
     
      // indicate this is a TOF packet: using last byte 
      nbuf[39] = 0x0;
    
    
      vbuf = nbuf;    
      if (nbuf == bufferP)
        nbuf = bufferQ;
      else
        nbuf = bufferP; 
      if ((tof_graph_state == 1) || (single_shot_measure_state == 1))
      {      
        TDC1000_PQBufferReady = 1;
      }
      // restore upstream controls: echo qual threshold and pga gain
      if (TDC1000_Downstream_Control == 1)
      {
        TI_TDC1000_SPIByteWriteReg(TI_TDC1000_CONFIG3_REG, save_cfg3);
        TI_TDC1000_SPIByteWriteReg(TI_TDC1000_TOF1_REG, save_tof1);        
      }      
    }
    if (measure_one_temp == 1)
    {
      measure_one_temp = 0;
      TI_TDC1000_SPIByteWriteReg(TI_TDC1000_CONFIG2_REG, save1);
      TI_TDC7200_SPIByteWriteReg(TI_TDC7200_CONFIG2_REG, save2);
      // clear error flags and reset state machine
      TI_TDC1000_SPIByteWriteReg(TI_TDC1000_ERROR_FLAGS_REG, 0x03);      
    }    
    if (tdc_power_cycle_flag)
    {
      // Disable device
      TI_TDC7200_ENABLE_PxOUT &= ~TI_TDC7200_ENABLE_PIN;    
      TI_TDC1000_ENABLE_PxOUT &= ~TI_TDC1000_ENABLE_PIN;                         // disable afe
    
      // disable osc after completing measurement
      TI_TDC1000_OSCENABLE_PxOUT &= ~TI_TDC1000_OSCENABLE_PIN;                   // Set pin low: disable afe osc
    }
  }
}
//******************************************************************************
void MSP430Timer_tdc_trigger_measure(void)
{
  
  if ((continuous_trigger_state == 1) || (tof_graph_state == 1) || (single_shot_measure_state == 1))
  {
    uint32_t tout = 0; 
    
    
    handle_hv_driver_pre_fire();

    tstop = 0;
    // clear interrupt flags & enable interrupts
    TA0CTL &= ~TAIFG;
    TA0CCTL0 &= ~CCIFG;
    TA0CCTL1 &= ~CCIFG;
    TA0CCTL0 |= CCIE;
    TA0CCTL1 |= CCIE;
    // enable overflow interrupt  
    TA0CTL |= TAIE;
    
    // reset flag to wait on
    timer_done_flag = 0;    
    // Trigger the AFE (by CPU)
    // make sure jumper setting on CPU  
    TI_TDC1000_TRIGGER_PxOUT |=  TI_TDC1000_TRIGGER_PIN;
    __delay_cycles(5);
    TI_TDC1000_TRIGGER_PxOUT &= ~TI_TDC1000_TRIGGER_PIN;
    
    handle_hv_driver_post_fire();
    
    //wait for flag to be set
    while(!timer_done_flag)
    {
      tout++;
      // 1us delay below at 24MHz master clock
      __delay_cycles(24);
      // tout default is 200000, wait atleast 200ms and timeout
      if (tout >= TIMEOUT_VALUE)
      {
        // clear error flags and reset state machine
        TI_TDC1000_SPIByteWriteReg(TI_TDC1000_ERROR_FLAGS_REG, 0x03);
        reset_device(TDC1000);         
        break;
      }
    }
    
    if (timer_done_flag)
    {
      mbuf[0] = tstart;
      mbuf[1] = tstart>>8;
      mbuf[2] = tstop;
      mbuf[3] = tstop>>8;
      mbuf[4] = ovf_final; 
    } else
    { // send empty buffer
      mbuf[0] = 0;
      mbuf[1] = 0;
      mbuf[2] = 0;
      mbuf[3] = 0;
      mbuf[4] = 0; 
    }      
    
    // indicate this is a TOF packet: using last byte 
    mbuf[39] = 0x0;   
    
    ubuf = mbuf;
    if (mbuf == bufferX)
      mbuf = bufferY;
    else
      mbuf = bufferX;
  
    if ((tof_graph_state == 1) || (single_shot_measure_state == 1))
    {      
      TDC1000_XYBufferReady = 1;
    }
    // make sure interrupts are disabled
    TA0CTL &= ~(TAIE + TAIFG);
    TA0CCTL0 &= ~(CCIE + CCIFG);
    TA0CCTL1 &= ~(CCIE + CCIFG);     
  }
}
//******************************************************************************
void handle_hv_driver_pre_fire(void)
{
    // Handle HV Driver Enable Command
    if ((measure_one_temp != 1) && ((TDC1000_HV_Driver_Enable1 == 1) || (TDC1000_HV_Driver_Enable2 == 1)))
    {
      if (TDC1000_HV_Boost_Power_Enable == 1)
      {
        // Power enable HV Boost
        TI_TDC1000_GPIO1_PxOUT |= TI_TDC1000_GPIO1_PIN;
        // we need delay for power to settle 
        // Equal to 0 is boost power always on condition
        if (TDC1000_HV_Boost_Power_Enable_Period != 0)
          timer_microsec_delay(TDC1000_HV_Boost_Power_Enable_Period);    
      }
      if (TDC1000_HV_Driver_Enable1 == 1)
        TI_TDC1000_GPIO7_PxOUT |= TI_TDC1000_GPIO7_PIN;
      if (TDC1000_HV_Driver_Enable2 == 1)
        TI_TDC1000_GPIO5_PxOUT |= TI_TDC1000_GPIO5_PIN;
      // we need totally about 20us delay before start pulse
      timer_microsec_delay(20);
    }    
}
//******************************************************************************
void handle_hv_driver_post_fire(void)
{
    // Handle HV Driver Enable Command
    if ((measure_one_temp != 1) && ((TDC1000_HV_Driver_Enable1 == 1) || (TDC1000_HV_Driver_Enable2 == 1)))
    {
      if ((TDC1000_HV_Driver_Enable1 == 1) && (TDC1000_HV_Driver_Enable2 == 1))
      {
        if (TDC1000_HV_Driver_Enable1_Period > TDC1000_HV_Driver_Enable2_Period)
          timer_microsec_delay(TDC1000_HV_Driver_Enable1_Period);
        else
          timer_microsec_delay(TDC1000_HV_Driver_Enable2_Period); 
        TI_TDC1000_GPIO7_PxOUT &= ~TI_TDC1000_GPIO7_PIN;
        TI_TDC1000_GPIO5_PxOUT &= ~TI_TDC1000_GPIO5_PIN;
      } else if (TDC1000_HV_Driver_Enable1 == 1)
      {
        timer_microsec_delay(TDC1000_HV_Driver_Enable1_Period);
        TI_TDC1000_GPIO7_PxOUT &= ~TI_TDC1000_GPIO7_PIN;
      } else
      {
        timer_microsec_delay(TDC1000_HV_Driver_Enable2_Period);
        TI_TDC1000_GPIO5_PxOUT &= ~TI_TDC1000_GPIO5_PIN;
      }
      // Equal to 0 is boost power always on condition
      if (TDC1000_HV_Boost_Power_Enable_Period != 0)      
        // Disable HV Boost power
        TI_TDC1000_GPIO1_PxOUT &= ~TI_TDC1000_GPIO1_PIN;      
    }
}
//******************************************************************************


