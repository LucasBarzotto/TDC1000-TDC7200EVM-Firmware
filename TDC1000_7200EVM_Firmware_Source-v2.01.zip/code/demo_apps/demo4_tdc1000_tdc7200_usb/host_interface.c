/* --COPYRIGHT--,BSD
* Copyright (c) 2014, Texas Instruments Incorporated
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
*
* * Redistributions of source code must retain the above copyright
* notice, this list of conditions and the following disclaimer.
*
* * Redistributions in binary form must reproduce the above copyright
* notice, this list of conditions and the following disclaimer in the
* documentation and/or other materials provided with the distribution.
*
* * Neither the name of Texas Instruments Incorporated nor the names of
* its contributors may be used to endorse or promote products derived
* from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
* THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
* PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
* EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
* OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
* WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
* --/COPYRIGHT--*/

#include <stdint.h>
#include <cstring>
//#include <cstdio>
#include <stdio.h>
#include "TI_TDC1000.h"
#include "TI_TDC7200.h"
#include "TI_TDC1000_register_settings.h"
#include "TI_MSP430.h"
#include "TI_MSP430_hardware_board.h"
#include "TI_MSP430_spi.h"
#include "host_interface.h"
#include "uart_commn.h"
#include "timer_queue.h"

#define ONE_MS 24000                      // 1ms at 24MHz
#define ONE_100_uS 2400                   // 100us delay at 24MHz  
//******************************************************************************
extern uint8_t timer_done_flag;
extern uint8_t single_shot_measure_state;
extern uint8_t tof_graph_state;
extern uint8_t continuous_trigger_state;
extern uint8_t tdc_power_cycle_flag;
extern uint16_t timer_trigger_freq;
extern uint16_t fwd2rev_flow_delay;
extern uint8_t cpu_clk_period;
extern uint16_t extosc_wakeup_period;
extern uint8_t USB_disable(void);
extern void TI_TDC1000_reg_init(uint8_t);
extern void TI_TDC7200_reg_init(uint8_t);
extern void timer_microsec_delay(uint16_t);
extern uint8_t TDC1000_HV_Driver_Enable1;
extern uint8_t TDC1000_HV_Driver_Enable2;
extern uint16_t TDC1000_HV_Driver_Enable1_Period;
extern uint16_t TDC1000_HV_Driver_Enable2_Period;
extern uint8_t TDC1000_HV_Boost_Power_Enable;
extern uint16_t TDC1000_HV_Boost_Power_Enable_Period;
extern uint8_t TDC1000_Impedance_Matching_Enable;
extern uint8_t interleaved_temp_measure;
extern uint16_t count_per_temp;
extern uint16_t nsamp_done;
extern float tdc_clk_period;
extern uint8_t tdc_ds_eq_thld;
extern uint8_t tdc_ds_pga_gain;
extern uint8_t TDC1000_Downstream_Control;
extern uint8_t outString[];
//******************************************************************************
// UART Stream control: disable by default
uint8_t TDC1000_UART_Stream = 0;

// MSP430Timer_TDC: disable by default
uint8_t TDC1000_MSP430Timer_TDC = 0;

uint8_t all_data[TDC7200_ALL_DATA_SIZE];
uint8_t double_resolution_flag=0;

void handle_reInit(uint8_t *pBuf, uint16_t pSize);
uint8_t get_TDC1000_mode(void);
void reset_device(uint8_t);

uint8_t char2nibble(uint8_t db);      
uint8_t TDC1000_address, TDC7200_address; 
uint8_t TDC7200_status = 0;

// default settings
uint8_t TDC7200_reg_local_copy[10] = {0x02, 0x40, 0x0, 0x07, 0xFF, 0xFF, 0xFF, 0xFF, 0x0, 0x0 };

uint8_t TDC1000_reg_local_copy[10] = {0x45, 0x40, 0x0, 0x03, 0x1F, 0x0, 0x0, 0x03, 0x19, 0x0 };
//******************************************************************************
// Parse Command, then execute
uint8_t handleHostCommand(uint8_t *pBuf, uint16_t pSize)
{
  uint8_t host_response = 0;
  uint16_t word_data;
  uint8_t nxt_byte, byte_data;
  uint32_t long_data;
  
  nxt_byte = char2nibble(pBuf[0]);
  nxt_byte = (nxt_byte << 4) + char2nibble(pBuf[1]);
  switch(nxt_byte)
  {
    case Command_LoopPacket:  
    {
      host_response = 1;
      break;
    }
    case Command_ReInit: 
    {
      handle_reInit(pBuf, pSize);
      host_response = 1;
      break;
    }    
    case Command_TDC1000_SPI_Byte_Write:
    {
      TDC1000_address = char2nibble(pBuf[2]);
      TDC1000_address = (TDC1000_address << 4) + char2nibble(pBuf[3]);
      
      byte_data = char2nibble(pBuf[4]);
      byte_data = (byte_data <<4) + char2nibble(pBuf[5]);
      // need to save local copy because on error we want to reset TDC1000
      // and reload saved registers    
      TDC1000_reg_local_copy[TDC1000_address] = byte_data;      
      TI_TDC1000_SPIByteWriteReg(TDC1000_address, byte_data);
      host_response = 1;
      break;
    }
    case Command_TDC1000_SPI_Byte_Read:
    {
      TDC1000_address = char2nibble(pBuf[2]);
      TDC1000_address = (TDC1000_address << 4) + char2nibble(pBuf[3]);
      byte_data = TI_TDC1000_SPIByteReadReg(TDC1000_address);
      pBuf[8] = byte_data;
      host_response = 1;
      break;
    }
    case Command_Start_TOF_One_Shot:
    {
      single_shot_measure_state = 1;
      host_response = 1;
      break;
    }
    case Command_Start_TOF_Graph:
    {
      if (!TDC1000_MSP430Timer_TDC)
      {
        // low byte first
        word_data = char2nibble(pBuf[4]);
        word_data = (word_data <<4) + char2nibble(pBuf[5]);
        // high byte next
        word_data = (word_data <<4) + char2nibble(pBuf[2]);
        word_data = (word_data <<4) + char2nibble(pBuf[3]);
        if (word_data != 0)
        {
    	  interleaved_temp_measure = 1;
    	  count_per_temp = word_data;
        } else
        {
          interleaved_temp_measure = 0;
    	  count_per_temp = 0;
        }
        nsamp_done = 0;   
      }
      tof_graph_state = 1;
      host_response = 1;
      break;
    }
    case Command_End_TOF_Graph:
    {
      tof_graph_state = 0;
      if (!TDC1000_MSP430Timer_TDC)
      {
        interleaved_temp_measure = 0;
        count_per_temp = 0;  
        nsamp_done = 0;
      }
      TI_TDC1000_LINK_LED_PxOUT |= TI_TDC1000_LINK_LED_PIN;                        // Turn on LED
      TI_TDC1000_MEAS_LED_PxOUT &= ~TI_TDC1000_MEAS_LED_PIN;
      host_response = 1;
      break;
    }
    case Command_Start_Continuous_Trigger:
    {
      continuous_trigger_state = 1;
      host_response = 1;
      break;
    }
    case Command_Stop_Continuous_Trigger:
    {
      continuous_trigger_state = 0;
      TI_TDC1000_LINK_LED_PxOUT |= TI_TDC1000_LINK_LED_PIN;                        // Turn on LED
      TI_TDC1000_MEAS_LED_PxOUT &= ~TI_TDC1000_MEAS_LED_PIN;
      host_response = 1;
      break;
    }
  case Command_Firmware_Version_Read:
    {
      pBuf[8] = Firmware_VersionA;
      pBuf[9] = Firmware_VersionB;
      pBuf[10] = Firmware_VersionC;
      pBuf[11] = Firmware_VersionD;
      host_response = 1;
      break;
    }
  case Command_LED_Toggle:
    {
      // toggle LED
      TI_TDC1000_LINK_LED_PxOUT ^= TI_TDC1000_LINK_LED_PIN;
      host_response = 1;
      break;
    }
  case Command_MSP430SPI_Config_Read:
    {
      pBuf[8] = UCB0CTL0 & 0xC0;
      pBuf[9] = UCB0BR0;
      pBuf[10] = UCB0BR1;
      host_response = 1;
      break;
    }
  case Command_MSP430SPI_Config_Write:
    {
      byte_data = char2nibble(pBuf[2]);
      byte_data = (byte_data <<4) + char2nibble(pBuf[3]); 
      byte_data &= 0xC0;                                                       // make sure only top 2 bits are valid
      // low byte first
      word_data = char2nibble(pBuf[6]);
      word_data = (word_data <<4) + char2nibble(pBuf[7]);
      // high byte next
      word_data = (word_data <<4) + char2nibble(pBuf[4]);
      word_data = (word_data <<4) + char2nibble(pBuf[5]);      
      if (word_data < 1)
        word_data = 1;
      UCB0CTL1 |= UCSWRST;                                                     // **Disable USCI state machine**
      UCB0CTL0 &= 0x3F;                                                        // update 
      UCB0CTL0 |= byte_data;
      UCB0BRW = word_data;                                                     // UCLK divider;
      UCB0CTL1 &= ~UCSWRST;                                                    // **Initialize USCI state machine**
      host_response = 1;
      break;
    }
    case Command_TDC7200_SPI_Byte_Write:
    {                              
      TDC7200_address = char2nibble(pBuf[2]);
      TDC7200_address = (TDC7200_address << 4) + char2nibble(pBuf[3]);
      
      byte_data = char2nibble(pBuf[4]);
      byte_data = (byte_data <<4) + char2nibble(pBuf[5]);
      
      TI_TDC7200_SPIByteWriteReg(TDC7200_address, byte_data);
      // need to save local copy because TDC7200 enable pin is
      // power cycled and device doesn't retain register values      
      if (TDC7200_address <= TI_TDC7200_CLOCK_COUNTER_STOP_MASKL_REG)
        TDC7200_reg_local_copy[TDC7200_address] = byte_data;      
      host_response = 1;
      break;
    }
    case Command_TDC7200_SPI_Byte_Read:
    {
      TDC7200_address = char2nibble(pBuf[2]);
      TDC7200_address = (TDC7200_address << 4) + char2nibble(pBuf[3]);

      byte_data = TI_TDC7200_SPIByteReadReg(TDC7200_address);
      // need to save local copy because TDC7200 enable pin is
      // power cycled and device doesn't retain register values
      if (TDC7200_address <= TI_TDC7200_CLOCK_COUNTER_STOP_MASKL_REG)
        byte_data = TDC7200_reg_local_copy[TDC7200_address];      
      pBuf[8] = byte_data;
      host_response = 1;
      break;
    }
    case Command_TDC7200_SPI_Word_Read:
    {
      TDC7200_address = char2nibble(pBuf[2]);
      TDC7200_address = (TDC7200_address << 4) + char2nibble(pBuf[3]);

      long_data = TI_TDC7200_SPILongReadReg(TDC7200_address);
      pBuf[8] = long_data;
      pBuf[9] = long_data >> 8;
      pBuf[10] = long_data >> 16;      
      host_response = 1;
      break;
    }
  case Command_TDC7200_Status_Write:
    {
      byte_data = char2nibble(pBuf[2]);
      byte_data = (byte_data <<4) + char2nibble(pBuf[3]); 
      if (byte_data)
      {
        TI_TDC1000_OSCENABLE_PxOUT |= TI_TDC1000_OSCENABLE_PIN;                // Set EXTOSC_STBY OFF
        TI_TDC7200_ENABLE_PxOUT |= TI_TDC7200_ENABLE_PIN;                      // Enable device
        TDC7200_status = 1;
      } else
      {
        TI_TDC1000_OSCENABLE_PxOUT &= ~TI_TDC1000_OSCENABLE_PIN;               // Set EXTOSC_STBY ON        
        TI_TDC7200_ENABLE_PxOUT &= ~TI_TDC7200_ENABLE_PIN;                     // Disable device
        TDC7200_status = 0;
      }
    }
  case Command_TDC7200_Status_Read:
    {
      pBuf[8] = TDC7200_status;
      host_response = 1;
      break;
    }
   case Command_Set_ExtOSC_Wakeup_Delay:
    {                              
      // low byte first
      word_data = char2nibble(pBuf[4]);
      word_data = (word_data <<4) + char2nibble(pBuf[5]);
      // high byte next
      word_data = (word_data <<4) + char2nibble(pBuf[2]);
      word_data = (word_data <<4) + char2nibble(pBuf[3]); 

 //     if (word_data < 2000)
 //       word_data = 2000;
       

      // set extl osc max wakeup period (minimum 2ms)
      TA0CCR0 = word_data; 
      extosc_wakeup_period = word_data;
      host_response = 1;
      break;
    }
   case Command_Set_Timer_Trigger_Freq:
    {                              
      // low byte first
      word_data = char2nibble(pBuf[4]);
      word_data = (word_data <<4) + char2nibble(pBuf[5]);
      // high byte next
      word_data = (word_data <<4) + char2nibble(pBuf[2]);
      word_data = (word_data <<4) + char2nibble(pBuf[3]); 

      timer_trigger_freq = word_data;
      
      host_response = 1;
      break;
    }
   case Command_Set_Cpu_Clk_Period:
    {                              
      // byte data
      byte_data = char2nibble(pBuf[2]);
      byte_data = (byte_data <<4) + char2nibble(pBuf[3]); 

      // 24MHz system clock
      cpu_clk_period = 24 - byte_data - 1;
      TA2CCR0 = cpu_clk_period;                                                   // PWM Period
      TA2CCR2 = (cpu_clk_period+1)/2;                                             // CCR2 PWM duty cycle
      host_response = 1;
      break;
    }
   case Command_Read_Timer_Trigger_Freq:
    {
      pBuf[8] = timer_trigger_freq;
      pBuf[9] = timer_trigger_freq >> 8;
      host_response = 1;
      break;
    }
   case Command_Read_Cpu_Clk_Period:
    {
      pBuf[8] = 24 - cpu_clk_period - 1;
      host_response = 1;
      break;
    }
  case Command_Read_ExtOSC_Wakeup_Period:
    {
      pBuf[8] = extosc_wakeup_period;
      pBuf[9] = extosc_wakeup_period >> 8;
      host_response = 1;      
    }
  case Command_Enter_MSP430_BSL:
    {
      USB_disable();
      __disable_interrupt();
      ((void (*)())0x1000)();
      host_response = 1;
      break;
    }
  case Command_Reset_TDC7200:
    {
      reset_device(TDC7200);
      host_response = 1;
      break;
    }
  case Command_Reset_TDC1000:
    {
      reset_device(TDC1000);
      host_response = 1;
      break;
    }
  case Command_TDC7200_Set_Double_Resolution:
    {
      uint8_t reg_address;
      reg_address = 0x0b;
      
      all_data[0] = 0;
      all_data[1] = 0x01;
      
      TI_TDC7200_SPIAutoIncWriteReg(reg_address, all_data, 2); 
      
      double_resolution_flag = 1;
      
      host_response = 1;
      break;
    }
  case Command_TDC7200_Clear_Double_Resolution:
    {
      uint8_t reg_address;
      reg_address = 0x0b;
      
      all_data[0] = 0;
      all_data[1] = 0;
      
      TI_TDC7200_SPIAutoIncWriteReg(reg_address, all_data, 2);

      double_resolution_flag = 0;      
      
      host_response = 1;
      break;
    }
  case Command_TDCxxxx_Disable_Power_Cycle:
    {     
      tdc_power_cycle_flag = 0;
      
      // enable external osc before starting measurement
      TI_TDC1000_OSCENABLE_PxOUT |= TI_TDC1000_OSCENABLE_PIN;                    // Set pin high: enable afe osc
      
      // use default delay if input is 0
      timer_microsec_delay(0);
        
      // enable AFE & wait wakeup period of atleast 5us
      TI_TDC1000_ENABLE_PxOUT |= TI_TDC1000_ENABLE_PIN;                          // enable afe
      __delay_cycles(120);
    
      // Enable device
      TI_TDC7200_ENABLE_PxOUT |= TI_TDC7200_ENABLE_PIN;                            
      
      // wait for TDC7200 wakeup delay
      timer_microsec_delay(TDC7200_WAKEUP_PERIOD); 
      
      // init TDC7200 with local saved data
      TI_TDC7200_SPIAutoIncWriteReg(TI_TDC7200_CONFIG1_REG, TDC7200_reg_local_copy, 10);
      
      host_response = 1;      
      break;
    }
  case Command_TDCxxx_Enable_Power_Cycle:
    {     
      tdc_power_cycle_flag = 1;

      // Disable device
      TI_TDC7200_ENABLE_PxOUT &= ~TI_TDC7200_ENABLE_PIN;    
      TI_TDC1000_ENABLE_PxOUT &= ~TI_TDC1000_ENABLE_PIN;                       // disable afe
    
      // disable osc 
      TI_TDC1000_OSCENABLE_PxOUT &= ~TI_TDC1000_OSCENABLE_PIN;                 // Set pin low: disable afe osc
      
      host_response = 1;
      break;
    }
  case Command_Enable_CPU_Clock:
    {     
      // 11/4: Enable Timer2 PWM output on Pin P2.5
      TI_TDC1000_XCLK_PxSEL |= TI_TDC1000_XCLK_PIN;                                  
      host_response = 1;
      break;
    }
  case Command_Disable_CPU_Clock:
    {     
      // 11/4: Disable Timer2 PWM output on Pin P2.5
      TI_TDC1000_XCLK_PxSEL &= ~TI_TDC1000_XCLK_PIN;                                  
      host_response = 1;
      break;
    }
  case Command_Enable_HV_DRIVER_EN1:
    {
      // get hv driver enable period in us
      // low byte first
      word_data = char2nibble(pBuf[4]);
      word_data = (word_data <<4) + char2nibble(pBuf[5]);
      // high byte next
      word_data = (word_data <<4) + char2nibble(pBuf[2]);
      word_data = (word_data <<4) + char2nibble(pBuf[3]);      
      
      TDC1000_HV_Driver_Enable1 = 1;
      TDC1000_HV_Driver_Enable1_Period = word_data;
      host_response = 1;
      break;
    }
  case Command_Disable_HV_DRIVER_EN1:
    {     
      TDC1000_HV_Driver_Enable1 = 0;
      host_response = 1;
      break;
    }    
  case Command_Enable_HV_DRIVER_EN2:
    {
      // get hv driver enable period in us
      // low byte first
      word_data = char2nibble(pBuf[4]);
      word_data = (word_data <<4) + char2nibble(pBuf[5]);
      // high byte next
      word_data = (word_data <<4) + char2nibble(pBuf[2]);
      word_data = (word_data <<4) + char2nibble(pBuf[3]);
      
      TDC1000_HV_Driver_Enable2 = 1;
      TDC1000_HV_Driver_Enable2_Period = word_data;
      host_response = 1;
      break;
    }
  case Command_Disable_HV_DRIVER_EN2:
    {     
      TDC1000_HV_Driver_Enable2 = 0;
      host_response = 1;
      break;
    }
   case Command_Set_FWD2REV_Flow_Delay:
    {                              
      // low byte first
      word_data = char2nibble(pBuf[4]);
      word_data = (word_data <<4) + char2nibble(pBuf[5]);
      // high byte next
      word_data = (word_data <<4) + char2nibble(pBuf[2]);
      word_data = (word_data <<4) + char2nibble(pBuf[3]); 

      fwd2rev_flow_delay = word_data;
      
      host_response = 1;
      break;
    }
   case Command_Read_FWD2REV_Flow_Delay:
    {
      pBuf[8] = fwd2rev_flow_delay;
      pBuf[9] = fwd2rev_flow_delay >> 8;
      host_response = 1;
      break;
    }
  case Command_Enable_HV_Boost_Power:
    {
      // get hv driver enable period in us
      // low byte first
      word_data = char2nibble(pBuf[4]);
      word_data = (word_data <<4) + char2nibble(pBuf[5]);
      // high byte next
      word_data = (word_data <<4) + char2nibble(pBuf[2]);
      word_data = (word_data <<4) + char2nibble(pBuf[3]);      
      
      TDC1000_HV_Boost_Power_Enable = 1;
      TDC1000_HV_Boost_Power_Enable_Period = word_data;
      // Alway ON condition, enable boost power right away
      if (TDC1000_HV_Boost_Power_Enable_Period == 0)
      {
        // enable boost power
        TI_TDC1000_GPIO1_PxOUT |= TI_TDC1000_GPIO1_PIN;                                 
      }
      // Note: GPIO1 pin is reused between impedance matching and HV Boost Power Enable 
      // Make sure both are not enabled at the same time
      TDC1000_Impedance_Matching_Enable = 0;
      host_response = 1;
      break;
    }
  case Command_Disable_HV_Boost_Power:
    {     
      TDC1000_HV_Boost_Power_Enable = 0;
      // Disable HV Boost power
      TI_TDC1000_GPIO1_PxOUT &= ~TI_TDC1000_GPIO1_PIN;      
      host_response = 1;
      break;
    }
  case Command_Enable_Impedance_Matching:
    {     
      TDC1000_Impedance_Matching_Enable = 1;
      // Note: GPIO1 pin is reused between impedance matching and HV Boost Power Enable
      // Make sure both are not enabled at the same time
      TDC1000_HV_Boost_Power_Enable = 0; 
      // As of now enable, GPIO2 (AMP_EN) whenever impedance matching is enabled
      TI_TDC1000_GPIO2_PxOUT |= TI_TDC1000_GPIO2_PIN;                                    
      host_response = 1;
      break;
    }
  case Command_Disable_Impedance_Matching:
    {     
      TDC1000_Impedance_Matching_Enable = 0;
      TI_TDC1000_GPIO1_PxOUT &= ~TI_TDC1000_GPIO1_PIN;                         // disable pin
      TI_TDC1000_GPIO2_PxOUT &= ~TI_TDC1000_GPIO2_PIN;                         // disable pin
      host_response = 1;
      break;
    }
   case Command_Set_Tdc_Clk_Period:
    {
      float tmp_clk;
      // byte data (up to 2 digits max) gives integer MHz
      byte_data = char2nibble(pBuf[2]);
      byte_data = (byte_data <<4) + char2nibble(pBuf[3]);
      
      tmp_clk = (float) byte_data;

      // byte data (up to 4 digits: first 2 digits) gives fractional MHz
      byte_data = char2nibble(pBuf[6]);
      byte_data = (byte_data <<4) + char2nibble(pBuf[7]);
      
      tmp_clk += (((float) byte_data)/100.0);
      
      // byte data (up to 4 digits: last 2 digits) gives fractional MHz
      byte_data = char2nibble(pBuf[4]);
      byte_data = (byte_data <<4) + char2nibble(pBuf[5]);
      
      tmp_clk += (((float) byte_data)/10000.0);
      // calculate in ns
      tdc_clk_period = 1000.0 / tmp_clk;
  
      host_response = 1;
      break;
    }
   case Command_Enable_Downstream_Control:
    {
      
      // byte data gives downstream echo qual threshold selection (0 to 7)
      byte_data = char2nibble(pBuf[2]);
      byte_data = (byte_data <<4) + char2nibble(pBuf[3]);
      
      tdc_ds_eq_thld = byte_data;

      // byte data gives downstream pga gain (0 to 7)
      byte_data = char2nibble(pBuf[4]);
      byte_data = (byte_data <<4) + char2nibble(pBuf[5]);
      
      tdc_ds_pga_gain = byte_data << 5;
      
      // enable tdc downstream control
      TDC1000_Downstream_Control = 1;
  
      host_response = 1;
      break;
    }
   case Command_Disable_Downstream_Control:
    {
      // disable tdc downstream control
      TDC1000_Downstream_Control = 0;
      host_response = 1;
      break;
    }
  case Command_Set_DS_Echo_Qual_Thld:
    {
      // byte data gives downstream echo qual threshold selection (0 to 7)
      byte_data = char2nibble(pBuf[2]);
      byte_data = (byte_data <<4) + char2nibble(pBuf[3]);
      
      tdc_ds_eq_thld = byte_data;
  
      host_response = 1;
      break;      
    }
  case Command_Set_DS_PGA_Gain:
    {
      // byte data gives downstream pga selection selection (0 to 7)
      byte_data = char2nibble(pBuf[2]);
      byte_data = (byte_data <<4) + char2nibble(pBuf[3]);
      
      tdc_ds_pga_gain = byte_data << 5;
  
      host_response = 1;
      break;      
    }
  case Command_Read_DS_Echo_Qual_Thld:
    {
      
      pBuf[8] = tdc_ds_eq_thld;
  
      host_response = 1;
      break;      
    }
  case Command_Read_DS_PGA_Gain:
    {

      pBuf[8] = tdc_ds_pga_gain >> 5;
      
      host_response = 1;
      break;      
    }
   case Command_Enable_UART_Stream:
    {      
      // enable UART Stream
      TDC1000_UART_Stream = 1; 
      // Init UART
      InitUART();
      sprintf((char *)outString, "Hello World \r\n");
      putsUART((unsigned char *)outString,strlen((char *)outString));      
      host_response = 1;
      break;
    }
   case Command_Disable_UART_Stream:
    {
      // disable UART Stream
      TDC1000_UART_Stream = 0;
      host_response = 1;
      break;
    }
   case Command_Enable_MSP430Timer_TDC:
    {      
      // enable MSP430Timer_TDC
      TDC1000_MSP430Timer_TDC = 1; 
      
      // init timer0 A0 for programmable external osc wake up time
      // or when MSP430TIMER_TDC is true, init as capture timer to continuously run
      timer0_A0_init();       
      
      // reset TDC1000 
      reset_device(TDC1000);
      // disable TDC7200
      TI_TDC7200_ENABLE_PxOUT &= ~TI_TDC7200_ENABLE_PIN;                       // disable device
      host_response = 1;
      break;
    }
   case Command_Disable_MSP430Timer_TDC:
    {
      // disable MSP430Timer_TDC
      TDC1000_MSP430Timer_TDC = 0;
      // init timer0 A0 for programmable external osc wake up time
      // or when MSP430TIMER_TDC is true, init as capture timer to continuously run
      timer0_A0_init();

      // reset TDC1000 
      reset_device(TDC1000);

      // reset TDC7200
      reset_device(TDC1000);
      
      host_response = 1;
      break;
    }     
  default:
    {
      host_response = 1;
      break;
    }    
  }
  return (host_response);
}
//******************************************************************************
void handle_reInit(uint8_t *pBuf, uint16_t pSize)
{
}
//******************************************************************************      
uint8_t char2nibble(uint8_t db)
{
  if ((db >= '0') && (db <= '9'))
    return (db-'0');
  else if ((db >= 'A') && (db <= 'F'))
    return (db-'A'+0xa);
  else if ((db >= 'a') && (db <= 'f'))
    return (db-'a'+0xa);
  else
    return (db);
}

//****************************************************************************** 
uint8_t get_TDC1000_mode(void)
{
  uint8_t mch, chswp, meas_mode, bdata, mx_sel;
  uint8_t device_mode;
  
  bdata = TI_TDC1000_SPIByteReadReg(TI_TDC1000_CONFIG2_REG);
  meas_mode = bdata & 0x03;
  mch = (bdata & 0x08)>>3;
  chswp = (bdata & 0x10)>>4;
  mx_sel = (bdata & 0x40)>>6;
  
  if (mx_sel == TOF_MEASUREMENT)
  {
    if ((chswp == ENABLED) && (mch == DISABLED) && (meas_mode == MULTI_CYCLE))
      device_mode = AUTO_FLOW;
    else if (mch == ENABLED)
      device_mode = MANUAL_FLOW;
    else
      device_mode = REGULAR_TOF;
  } else
    device_mode = REGULAR_TMP;
  return device_mode;
}
//******************************************************************************
void reset_device(uint8_t dev)
{
  // clear the TA0 control registers to reset state
  // this is the msp430 TDC timer
  TA0CCTL0 = 0;
  TA0CCTL1 = 0;
  TA0CTL = 0; 
  // clear the TA1 control registers to reset state
  // this is the trigger timer
  TA1CCTL0 = 0;
  TA1CCTL1 = 0;
  TA1CTL = 0;  
  
  if (dev == TDC1000)
  {
    TI_TDC1000_RESET_PxOUT |= TI_TDC1000_RESET_PIN;                   // reset device
    // wait for 10usec  
    __delay_cycles(240);
    TI_TDC1000_RESET_PxOUT &= ~TI_TDC1000_RESET_PIN;                  // Enable device
    // give atleast 500us
    __delay_cycles(1200000);      
    TI_TDC1000_reg_init(REG_REINIT); 
  } else if (dev == TDC7200)
  {
    TI_TDC7200_ENABLE_PxOUT &= ~TI_TDC7200_ENABLE_PIN;                 // disable device
    // wait for 1sec for the cap to discharge
    __delay_cycles(24000000);
    TI_TDC7200_ENABLE_PxOUT |= TI_TDC7200_ENABLE_PIN;                  // Enable device
    // give atleast 500us
    __delay_cycles(1200000);
    TI_TDC7200_reg_init(REG_REINIT);    
  }
  timer0_A0_init();
  timer1_A0_init();  
}
//******************************************************************************
