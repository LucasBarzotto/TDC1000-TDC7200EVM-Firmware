//******************************************************************************
//  Demo Application01 for MSP430/TDC7200 Interface Code Library v1.0
//  Byte Read/ Byte Write TDC7200 Registers
//
//                MSP430F5529
//             -----------------
//         /|\|              XIN|-
//          | |                 |  
//          --|RST          XOUT|-
//            |                 |
//            |    P3.0/UCB0SIMO|--> SDI 
//            |    P3.1/UCB0SOMI|<-- SDO 
//            |     P3.2/UCB0CLK|--> CLK 
//            |             P2.6|--> CSB 
//            |             P2.4| 
//            |                 | 
//            |             P1.2|
//
//   Vishy Natarajan
//   Texas Instruments Inc.
//   March 2013
//   Built with IAR Embedded Workbench Version:  5.5x
//******************************************************************************
/*  Copyright 2011-2012 Texas Instruments Incorporated. All rights reserved.

  IMPORTANT: Your use of this Software is limited to those specific rights
  granted under the terms of a software license agreement between the user who
  downloaded the software, his/her employer (which must be your employer) and
  Texas Instruments Incorporated (the "License"). You may not use this Software
  unless you agree to abide by the terms of the License. The License limits your
  use, and you acknowledge, that the Software may not be modified, copied or
  distributed unless embedded on a Texas Instruments microcontroller which is 
  integrated into your product. Other than for the foregoing purpose, you may 
  not use, reproduce, copy, prepare derivative works of, modify, distribute, 
  perform, display or sell this Software and/or its documentation for any 
  purpose.

  YOU FURTHER ACKNOWLEDGE AND AGREE THAT THE SOFTWARE AND DOCUMENTATION ARE
  PROVIDED �AS IS� WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
  INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF MERCHANTABILITY, TITLE,
  NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL TEXAS
  INSTRUMENTS OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER CONTRACT,
  NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR OTHER LEGAL
  EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES INCLUDING BUT NOT
  LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR CONSEQUENTIAL
  DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF SUBSTITUTE GOODS,
  TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES (INCLUDING BUT NOT
  LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

  Should you have any questions regarding your right to use this Software,
  contact Texas Instruments Incorporated at www.TI.com.
*******************************************************************************/

#include <stdint.h>
#include "TI_TDC7200.h"
#include "TI_MSP430.h"
#include "TI_MSP430_hardware_board.h"
#include "TI_MSP430_spi.h"
#include "HAL_PMM.h"

void Init_Clock (void);
void InitMCU(void);


// Test TDC7200 Register Read/Write & Conversion
uint32_t clk_count;
uint8_t read_val[3], all_data[TDC7200_ALL_DATA_SIZE], byte_data;
uint32_t tout = 0;
//******************************************************************************
void main(void)
{
 
    
  WDTCTL = WDTPW+WDTHOLD;                                                      // Stop WDT 
  
  TI_TDC1000_LINK_LED_PxOUT |= TI_TDC1000_LINK_LED_PIN;                      // Set LINK_LED ON
  TI_TDC1000_LINK_LED_PxDIR |= TI_TDC1000_LINK_LED_PIN;                      // Set pin direction is output

  TI_TDC1000_OSCENABLE_PxOUT |= TI_TDC1000_OSCENABLE_PIN;                    // Set pin high: enable afe osc
//  TI_TDC1000_OSCENABLE_PxOUT &= ~TI_TDC1000_OSCENABLE_PIN;
  TI_TDC1000_OSCENABLE_PxDIR |= TI_TDC1000_OSCENABLE_PIN;                    // Set pin direction is output

  
  TI_TDC7200_ENABLE_PxOUT |= TI_TDC7200_ENABLE_PIN;                            // Enable device
  TI_TDC7200_ENABLE_PxDIR |= TI_TDC7200_ENABLE_PIN;                            // Set pin direction output  
  
//  TI_TDC7200_FLAG_PxOUT |= TI_TDC7200_FLAG_PIN;                                // Flag Input Pull up enable
//  TI_TDC7200_FLAG_PxREN |= TI_TDC7200_FLAG_PIN;                                // Flag Input Resistor enable
//  TI_TDC7200_FLAG_PxDIR &= ~TI_TDC7200_FLAG_PIN;                               // Set pin direction input

  // configure Port Pin to handle Interrupt Bar Output (INTB) from TDC7200
  TI_TDC7200_INTB_PxDIR &= ~TI_TDC7200_INTB_PIN;                               // Set up port pin for INTB
  TI_TDC7200_INTB_PxOUT |= TI_TDC7200_INTB_PIN;                                // INTB Input Pull up enable  
  TI_TDC7200_INTB_PxREN |= TI_TDC7200_INTB_PIN;                                // INTB Input Resistor enable  
  TI_TDC7200_INTB_PxIES |= TI_TDC7200_INTB_PIN;                                // Interrupt Edge Select
  TI_TDC7200_INTB_PxIFG &= ~TI_TDC7200_INTB_PIN;                               // Clear Interrupt Flag
//  TI_TDC7200_INTB_PxIE |= TI_TDC7200_INTB_PIN;                               // Enable Port interrupt
  
  // oscillator fail if LED keeps flashing after InitMCU     
  InitMCU();
         
  TI_TDC7200_SPISetup();                                                       // Initilaize MSP430 SPI Block 

// Test TDC7200 Register Read/Write & Conversion
  read_val[0] = TI_TDC7200_SPIByteReadReg(0x00);
  read_val[1] = TI_TDC7200_SPIByteReadReg(0x01);
  read_val[2] = TI_TDC7200_SPIByteReadReg(0x03);      
  TI_TDC7200_SPIByteWriteReg(0x01, 0x40);
  read_val[0] = TI_TDC7200_SPIByteReadReg(0x00);
  read_val[1] = TI_TDC7200_SPIByteReadReg(0x01);
  read_val[2] = TI_TDC7200_SPIByteReadReg(0x03);

  // read config1 register
  byte_data = TI_TDC7200_SPIByteReadReg(TI_TDC7200_CONFIG1_REG);
  // set mode 2 & start measurement bit
  byte_data |= 0x03;
  TI_TDC7200_SPIByteWriteReg(TI_TDC7200_CONFIG1_REG, byte_data);
      
  //wait for INTB pin to go low
  tout = 0;
  while(TI_TDC7200_INTB_PxIN & TI_TDC7200_INTB_PIN)                      
  {
    tout++;
    if (tout >= TIMEOUT_VALUE)
       break;
  }
  TI_TDC7200_SPIAllReadReg(all_data);
  clk_count = TI_TDC7200_SPILongReadReg(0x11);
  
  // test if byte write/read values match
  if (read_val[1]  == 0x40)
  {
     while (1)                                                                 // no error: blink LED continuously
    {
      __delay_cycles(250000);
      __delay_cycles(250000);
      TI_TDC1000_LINK_LED_PxOUT ^= TI_TDC1000_LINK_LED_PIN;        
    }      
  } else
  {
    TI_TDC1000_LINK_LED_PxOUT &= ~TI_TDC1000_LINK_LED_PIN;                             // error: Set LED OFF  
  }
  __bis_SR_register(LPM0_bits + GIE);                                          // Enter LPM0, enable interrupts
  __no_operation();                                                            // For debugger 

}
//******************************************************************************
//******************************************************************************
/**
* @brief Function Name: Init_Clock .                                                
* @brief Description  : Initializes MSP430 clock module. 
* @param parameters   : none                                                    
* @return Value       : none                                                    
*/ 
//******************************************************************************
void Init_Clock(void)
{
  // Enable XT2 XIN/XOUT Pins
  P5SEL |= 0x0C;                            // Select XIN, XOUT on P5.3 and P5.2
  UCSCTL6 &= ~XT2OFF;                       // Enable XT2  
  UCSCTL6 |= XT2DRIVE_3; 
  UCSCTL3 |= SELREF_2;                      // FLLref = REFO
                                            // Since LFXT1 is not used,
                                            // sourcing FLL with LFXT1 can cause
                                            // XT1OFFG flag to set

  // ACLK=REFO,SMCLK=DCO,MCLK=DCO
  UCSCTL4 = SELA__REFOCLK + SELS__DCOCLKDIV + SELM__DCOCLKDIV;
  UCSCTL0 = 0x0000;                                                            // Set lowest possible DCOx, MODx 
  
  // Loop until XT1,XT2 & DCO stabilizes
  do
  {
    UCSCTL7 &= ~(XT2OFFG + XT1LFOFFG + DCOFFG);
                                            // Clear XT2,DCO fault flags
    SFRIFG1 &= ~OFIFG;                      // Clear fault flags
    TI_TDC1000_LINK_LED_PxOUT ^= TI_TDC1000_LINK_LED_PIN;                      // Toggle LED
  }while (SFRIFG1&OFIFG);                   // Test oscillator fault flag
  
  __bis_SR_register(SCG0);                                           // Disable the FLL control loop
  UCSCTL1 = DCORSEL_5;                                               // Select DCO range 16MHz operation
  UCSCTL2 |= 124;                                                    // Set DCO Multiplier for 8MHz
                                                                     // (N + 1) * FLLRef = Fdco
                                                                     // (249 + 1) * 32768 = 8MHz
                                                                     // (124 + 1) * 32768 = 4MHz
  __bic_SR_register(SCG0);                                           // Enable the FLL control loop

  // Worst-case settling time for the DCO when the DCO range bits have been
  // changed is n x 32 x 32 x f_MCLK / f_FLL_reference. See UCS chapter in 5xx
  // UG for optimization.
  // 32 x 32 x 8 MHz / 32,768 Hz = 250000 = MCLK cycles for DCO to settle
  __delay_cycles(250000);                                            // vishy:continue to keep 8MHz delay
  
                                            
  UCSCTL4 = SELA__DCOCLKDIV + SELS__XT2CLK + SELM__XT2CLK;                    // SMCLK=MCLK=XT2 = 24MHz

  // After changing UCSCTL4, loop again until XT1,XT2 & DCO stabilizes (Errat workaround?)
  do
  {
    UCSCTL7 &= ~(XT2OFFG + XT1LFOFFG + DCOFFG);
                                            // Clear XT2,DCO fault flags
    SFRIFG1 &= ~OFIFG;                      // Clear fault flags
    TI_TDC1000_LINK_LED_PxOUT ^= TI_TDC1000_LINK_LED_PIN;                      // Toggle LED
  }while (SFRIFG1&OFIFG);                   // Test oscillator fault flag   
   
  TI_TDC1000_LINK_LED_PxOUT |= TI_TDC1000_LINK_LED_PIN;                        // Turn on LED          
}
//******************************************************************************
/**
* @brief  Local functions.                           
*/

/**
* @brief Function Name:  InitMCU.                                                
* @brief Description  :  Initializes the MSP430 peripherals and modules.
* @param parameters   :  none                                                   
* @return Value       :  none                                                   
*/   
//******************************************************************************
void InitMCU(void)
{
  
  __disable_interrupt();                                                       // Disable global interrupts 
    SetVCore(3);
    Init_Clock();                                                              //Init clocks	
  __enable_interrupt();                                                        // enable global interrupts

}
//******************************************************************************
