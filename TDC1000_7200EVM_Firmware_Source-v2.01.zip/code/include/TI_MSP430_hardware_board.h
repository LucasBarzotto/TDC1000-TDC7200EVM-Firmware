/* --COPYRIGHT--,BSD
* Copyright (c) 2014, Texas Instruments Incorporated
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
*
* * Redistributions of source code must retain the above copyright
* notice, this list of conditions and the following disclaimer.
*
* * Redistributions in binary form must reproduce the above copyright
* notice, this list of conditions and the following disclaimer in the
* documentation and/or other materials provided with the distribution.
*
* * Neither the name of Texas Instruments Incorporated nor the names of
* its contributors may be used to endorse or promote products derived
* from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
* THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
* PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
* EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
* OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
* WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
* --/COPYRIGHT--*/

#ifndef HEADER_TI_MSP430_HARDWARE_BOARD_H

#define HEADER_FILE_TI_MSP430_HARDWARE_BOARD_H

//Select one of the following to define XCLK & also the pin# later down

#define TI_TDC1000_LINK_LED_PxOUT       P4OUT
#define TI_TDC1000_LINK_LED_PxDIR       P4DIR
#define TI_TDC1000_LINK_LED_PIN         BIT6

#define TI_TDC1000_MEAS_LED_PxOUT       P4OUT
#define TI_TDC1000_MEAS_LED_PxDIR       P4DIR
#define TI_TDC1000_MEAS_LED_PIN         BIT7

// HV Boost Power Enable: GPIO1 on schematic
// Note: same pin used for impedance matching
#define TI_TDC1000_GPIO1_PxOUT       P4OUT
#define TI_TDC1000_GPIO1_PxDIR       P4DIR
#define TI_TDC1000_GPIO1_PIN         BIT1

// Amplifier Enable: GPIO2 on schematic
// Note: This is enabled when impedance matching is enabled
#define TI_TDC1000_GPIO2_PxOUT       P4OUT
#define TI_TDC1000_GPIO2_PxDIR       P4DIR
#define TI_TDC1000_GPIO2_PIN         BIT2

// HV Driver Enable 1
#define TI_TDC1000_GPIO7_PxOUT       P1OUT
#define TI_TDC1000_GPIO7_PxDIR       P1DIR
#define TI_TDC1000_GPIO7_PxDS        P1DS
#define TI_TDC1000_GPIO7_PIN         BIT4

// HV Driver Enable 2
#define TI_TDC1000_GPIO5_PxOUT       P6OUT
#define TI_TDC1000_GPIO5_PxDIR       P6DIR
#define TI_TDC1000_GPIO5_PxDS        P6DS
#define TI_TDC1000_GPIO5_PIN         BIT0
                         
#define TI_TDC1000_STOP_PxOUT           P1OUT
#define TI_TDC1000_STOP_PxDIR           P1DIR
#define TI_TDC1000_STOP_PxSEL           P1SEL
#define TI_TDC1000_STOP_PIN             BIT1

#define TI_TDC1000_START_PxOUT          P1OUT
#define TI_TDC1000_START_PxDIR          P1DIR
#define TI_TDC1000_START_PxSEL          P1SEL
#define TI_TDC1000_START_PIN            BIT2

// changed from P1.3 to P2.2 & back to 1.3 (4/28/14 for estore release)
#define TI_TDC1000_TRIGGER_PxOUT        P1OUT
#define TI_TDC1000_TRIGGER_PxDIR        P1DIR
#define TI_TDC1000_TRIGGER_PIN          BIT3

// on the board this pin is P2.2 (SMCLK)  
// changed xclk to P1.3 and back to P2.2 (4/28/14)
// 10/28/14 change: B's red board uses P2.5 for CPU_CLK_OUT & P2.2 for CH_SEL
#define TI_TDC1000_XCLK_PxOUT           P2OUT
#define TI_TDC1000_XCLK_PxDIR           P2DIR
#define TI_TDC1000_XCLK_PxSEL           P2SEL
#define TI_TDC1000_XCLK_PIN             BIT5

#define TI_TDC1000_OSCENABLE_PxOUT      P1OUT
#define TI_TDC1000_OSCENABLE_PxDIR      P1DIR
#define TI_TDC1000_OSCENABLE_PIN        BIT7

#define TI_TDC1000_ENABLE_PxOUT         P2OUT
#define TI_TDC1000_ENABLE_PxDIR         P2DIR
#define TI_TDC1000_ENABLE_PIN           BIT1

#define TI_TDC1000_RESET_PxOUT          P2OUT
#define TI_TDC1000_RESET_PxDIR          P2DIR
#define TI_TDC1000_RESET_PIN            BIT3

#define TI_TDC1000_ERRB_PORTx           PORT_2
#define TI_TDC1000_ERRB_PxDIR           P2DIR
#define TI_TDC1000_ERRB_PxIE            P2IE
#define TI_TDC1000_ERRB_PxIES           P2IES
#define TI_TDC1000_ERRB_PxIFG           P2IFG
#define TI_TDC1000_ERRB_PxREN           P2REN
#define TI_TDC1000_ERRB_PxOUT           P2OUT
#define TI_TDC1000_ERRB_PxIN            P2IN
#define TI_TDC1000_ERRB_PIN             BIT4
#define TI_TDC1000_ERRB_VECTOR          PORT2_VECTOR

// 10/28/14 change: B's red board uses P2.5 for CPU_CLK_OUT & P2.2 for CH_SEL
#define TI_TDC1000_CHSEL_PxOUT          P2OUT
#define TI_TDC1000_CHSEL_PxDIR          P2DIR
#define TI_TDC1000_CHSEL_PIN            BIT2

#define TI_TDC1000_CSn_PxOUT            P2OUT
#define TI_TDC1000_CSn_PxDIR            P2DIR
#define TI_TDC1000_CSn_PIN              BIT7

#define TI_TDC7200_CSn_PxOUT            P2OUT
#define TI_TDC7200_CSn_PxDIR            P2DIR
#define TI_TDC7200_CSn_PIN              BIT6  

#define TI_TDC7200_ENABLE_PxOUT         P2OUT
#define TI_TDC7200_ENABLE_PxDIR         P2DIR
#define TI_TDC7200_ENABLE_PIN           BIT0

#define TI_TDC7200_INTB_PORTx           PORT_1
#define TI_TDC7200_INTB_PxDIR           P1DIR
#define TI_TDC7200_INTB_PxIE            P1IE
#define TI_TDC7200_INTB_PxIES           P1IES
#define TI_TDC7200_INTB_PxIFG           P1IFG
#define TI_TDC7200_INTB_PxREN           P1REN
#define TI_TDC7200_INTB_PxOUT           P1OUT
#define TI_TDC7200_INTB_PxIN            P1IN
#define TI_TDC7200_INTB_PIN             BIT5
#define TI_TDC7200_INTB_VECTOR          PORT1_VECTOR

//----------------------------------------------------------------------------
// Select which port will be used for interface to TDC1000
//----------------------------------------------------------------------------
//#define TI_TDC1000_SER_INTF            TI_TDC1000_SER_INTF_USCIA0_5xx   // 5xx, 6xx family USCIA0 SPI Interface to TDC1000
//#define TI_TDC1000_SER_INTF            TI_TDC1000_SER_INTF_USCIA1_5xx   // 5xx, 6xx family USCIA1 SPI Interface to TDC1000
//#define TI_TDC1000_SER_INTF            TI_TDC1000_SER_INTF_USCIA2_5xx   // 5xx, 6xx family USCIA2 SPI Interface to TDC1000
//#define TI_TDC1000_SER_INTF            TI_TDC1000_SER_INTF_USCIA3_5xx   // 5xx, 6xx family USCIA3 SPI Interface to TDC1000
#define TI_TDC1000_SER_INTF            TI_TDC1000_SER_INTF_USCIB0_5xx   // 5xx, 6xx family USCIB0 SPI Interface to TDC1000
//#define TI_TDC1000_SER_INTF            TI_TDC1000_SER_INTF_USCIB1_5xx   // 5xx, 6xx family USCIB1 SPI Interface to TDC1000
//#define TI_TDC1000_SER_INTF            TI_TDC1000_SER_INTF_USCIB2_5xx   // 5xx, 6xx family USCIB2 SPI Interface to TDC1000
//#define TI_TDC1000_SER_INTF            TI_TDC1000_SER_INTF_USCIB3_5xx   // 5xx, 6xx family USCIB3 SPI Interface to TDC1000
//#define TI_TDC1000_SER_INTF            TI_TDC1000_SER_INTF_USART0       // USART0 SPI Interface to TDC1000
//#define TI_TDC1000_SER_INTF            TI_TDC1000_SER_INTF_USART1       // USART1 SPI Interface to TDC1000
//#define TI_TDC1000_SER_INTF            TI_TDC1000_SER_INTF_USCIA0       // 2xx, 4xx family USCIA0 SPI Interface to TDC1000
//#define TI_TDC1000_SER_INTF            TI_TDC1000_SER_INTF_USCIA1       // 2xx, 4xx family USCIA1 SPI Interface to TDC1000
//#define TI_TDC1000_SER_INTF            TI_TDC1000_SER_INTF_USCIB0       // 2xx, 4xx family USCIB0 SPI Interface to TDC1000
//#define TI_TDC1000_SER_INTF            TI_TDC1000_SER_INTF_USCIB1       // 2xx, 4xx family USCIB1 SPI Interface to TDC1000
//#define TI_TDC1000_SER_INTF            TI_TDC1000_SER_INTF_USI          // G2xx value seris SPI Interface to TDC1000

#endif                                                                         // HEADER_FILE_TI_MSP430_HARDWARE_BOARD_H
