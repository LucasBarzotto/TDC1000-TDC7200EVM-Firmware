/* --COPYRIGHT--,BSD
* Copyright (c) 2014, Texas Instruments Incorporated
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
*
* * Redistributions of source code must retain the above copyright
* notice, this list of conditions and the following disclaimer.
*
* * Redistributions in binary form must reproduce the above copyright
* notice, this list of conditions and the following disclaimer in the
* documentation and/or other materials provided with the distribution.
*
* * Neither the name of Texas Instruments Incorporated nor the names of
* its contributors may be used to endorse or promote products derived
* from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
* THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
* PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
* EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
* OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
* WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
* OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
* EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
* --/COPYRIGHT--*/

#ifndef HEADER_FILE_TI_TDC1000_H

#define HEADER_FILE_TI_TDC1000_H

/************************************************************
* TI TDC1000 REGISTER SET ADDRESSES
************************************************************/

#define TI_TDC1000_CONFIG0_REG                        (0x00)                  //  
#define TI_TDC1000_CONFIG1_REG                        (0x01)                  //  
#define TI_TDC1000_CONFIG2_REG                        (0x02)                  //  
#define TI_TDC1000_CONFIG3_REG                        (0x03)                  //  
#define TI_TDC1000_CONFIG4_REG                        (0x04)                  //  
#define TI_TDC1000_TOF1_REG                           (0x05)                  //  
#define TI_TDC1000_TOF0_REG                           (0x06)                  //  
#define TI_TDC1000_ERROR_FLAGS_REG                    (0x07)                  // 
#define TI_TDC1000_TIMEOUT_REG                        (0x08)                  //  
#define TI_TDC1000_CLOCK_RATE_REG                     (0x09)                  //  

// Useful definitions
#define TDC1000_READ_BIT                              (0xBF)                  // bit 6 is 0 for read
#define TDC1000_WRITE_BIT                             (0x40)                  // bit 6 is 1 for write

#define ENABLED 1
#define DISABLED 0
#define MULTI_CYCLE 2
#define TOF_MEASUREMENT 0
#define TMP_MEASUREMENT 1

// Following are TDC1000 operation modes
#define REGULAR_TOF 0
#define REGULAR_TMP 1
#define AUTO_FLOW   2
#define MANUAL_FLOW 3

#endif  
